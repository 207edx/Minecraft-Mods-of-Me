package com.astro.backport.item;

import com.astro.backport.ModEnchants;
import com.astro.backport.util.AttrUtil;
import com.google.common.collect.Multimap;

import net.minecraft.enchantment.DamageEnchantment;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.enchantment.EnchantmentType;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.attributes.Attribute;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.inventory.EquipmentSlotType;
import net.minecraft.item.IItemTier;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.UseAction;
import net.minecraft.util.ActionResult;
import net.minecraft.util.DamageSource;
import net.minecraft.util.Hand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvents;
import net.minecraft.util.math.vector.Vector3d;
import net.minecraft.world.World;

/**
 * Spear. Left-click "jab" has 4.5 block reach (see SpearEvents), the Lunge enchantment dashes
 * the player forward on a jab, and holding use performs a charge attack while running.
 */
public class SpearItem extends Item {
    public static final double JAB_REACH = 4.5D;
    private final IItemTier tier;
    private final double damage;
    private final double speed;
    private Multimap<Attribute, AttributeModifier> modifiers;

    public SpearItem(IItemTier tier, double damage, double speed, Item.Properties properties) {
        super(properties.maxDamage(tier.getMaxUses()));
        this.tier = tier;
        this.damage = damage;
        this.speed = speed;
    }

    public IItemTier getTier() {
        return tier;
    }

    public float getChargeDamage() {
        return (float) damage + 1.0F;
    }

    @Override
    public Multimap<Attribute, AttributeModifier> getAttributeModifiers(EquipmentSlotType slot) {
        if (slot != EquipmentSlotType.MAINHAND) {
            return super.getAttributeModifiers(slot);
        }
        if (modifiers == null) {
            modifiers = AttrUtil.weapon(damage, speed - 4.0D);
        }
        return modifiers;
    }

    @Override
    public boolean hitEntity(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        stack.damageItem(1, attacker, entity -> entity.sendBreakAnimation(EquipmentSlotType.MAINHAND));
        return true;
    }

    @Override
    public int getItemEnchantability() {
        return tier.getEnchantability();
    }

    @Override
    public boolean getIsRepairable(ItemStack toRepair, ItemStack repair) {
        return tier.getRepairMaterial().test(repair) || super.getIsRepairable(toRepair, repair);
    }

    @Override
    public boolean canApplyAtEnchantingTable(ItemStack stack, Enchantment enchantment) {
        return enchantment.type == EnchantmentType.BREAKABLE
            || enchantment.type == ModEnchants.SPEAR_TYPE
            || enchantment instanceof DamageEnchantment
            || enchantment == Enchantments.KNOCKBACK
            || enchantment == Enchantments.FIRE_ASPECT
            || enchantment == Enchantments.LOOTING;
    }

    @Override
    public UseAction getUseAction(ItemStack stack) {
        return UseAction.SPEAR;
    }

    @Override
    public int getUseDuration(ItemStack stack) {
        return 72000;
    }

    @Override
    public ActionResult<ItemStack> onItemRightClick(World world, PlayerEntity player, Hand hand) {
        ItemStack stack = player.getHeldItem(hand);
        player.setActiveHand(hand);
        return ActionResult.resultConsume(stack);
    }

    /** Charge attack: after a short wind-up, running into entities hurts, knocks them back and dismounts riders. */
    @Override
    public void onUsingTick(ItemStack stack, LivingEntity living, int count) {
        if (living.world.isRemote || !(living instanceof PlayerEntity)) {
            return;
        }
        int used = getUseDuration(stack) - count;
        if (used < 6) {
            return;
        }
        PlayerEntity player = (PlayerEntity) living;
        double dx = player.getPosX() - player.prevPosX;
        double dz = player.getPosZ() - player.prevPosZ;
        double speedPerTick = Math.sqrt(dx * dx + dz * dz);
        if (speedPerTick < 0.12D) {
            return;
        }
        Vector3d look = player.getLookVec();
        Vector3d flat = new Vector3d(look.x, 0.0D, look.z).normalize();
        for (Entity target : player.world.getEntitiesWithinAABBExcludingEntity(player,
            player.getBoundingBox().grow(0.5D).offset(flat.x * 1.4D, 0.0D, flat.z * 1.4D))) {
            if (!(target instanceof LivingEntity) || !target.isAlive() || target.isRidingSameEntity(player)) {
                continue;
            }
            if (target.hurtResistantTime > 10) {
                continue;
            }
            float amount = getChargeDamage() + (float) (speedPerTick * 12.0D);
            if (target.attackEntityFrom(DamageSource.causePlayerDamage(player), amount)) {
                target.addVelocity(flat.x * 0.9D, 0.35D, flat.z * 0.9D);
                target.velocityChanged = true;
                if (target.isPassenger()) {
                    target.stopRiding();
                }
                for (Entity rider : target.getPassengers()) {
                    rider.stopRiding();
                }
                stack.damageItem(1, player, p -> p.sendBreakAnimation(player.getActiveHand()));
                player.world.playSound(null, target.getPosX(), target.getPosY(), target.getPosZ(),
                    SoundEvents.ENTITY_PLAYER_ATTACK_KNOCKBACK, SoundCategory.PLAYERS, 1.0F, 1.0F);
            }
        }
    }

    /** Lunge enchantment: dash forward when jabbing. Costs hunger. */
    public static void tryLunge(PlayerEntity player, ItemStack stack) {
        int level = EnchantmentHelper.getEnchantmentLevel(ModEnchants.LUNGE, stack);
        if (level <= 0 || player.isElytraFlying() || player.getFoodStats().getFoodLevel() <= 6) {
            return;
        }
        long now = player.world.getGameTime();
        if (player.getPersistentData().getLong("astro_lunge_cd") > now) {
            return;
        }
        player.getPersistentData().putLong("astro_lunge_cd", now + 25L);
        Vector3d look = player.getLookVec();
        double power = 0.55D + 0.35D * level;
        player.addVelocity(look.x * power, 0.12D + Math.max(0.0D, look.y) * power * 0.5D, look.z * power);
        player.velocityChanged = true;
        player.addExhaustion(1.5F * level);
        player.world.playSound(null, player.getPosX(), player.getPosY(), player.getPosZ(),
            SoundEvents.ITEM_TRIDENT_RIPTIDE_1, SoundCategory.PLAYERS, 0.8F, 1.3F);
    }
}
