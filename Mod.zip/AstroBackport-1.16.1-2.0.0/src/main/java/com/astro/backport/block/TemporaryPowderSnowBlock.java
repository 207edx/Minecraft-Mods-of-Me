package com.astro.backport.block;

import java.util.Random;

import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.server.ServerWorld;

/** Powder snow created by the Pokie Snowman barrier; melts after 8 seconds (survives restarts via scheduled ticks). */
public class TemporaryPowderSnowBlock extends PowderSnowBlock {
    public TemporaryPowderSnowBlock(Properties properties) {
        super(properties);
    }

    @Override
    public void onBlockAdded(BlockState state, World world, BlockPos pos, BlockState oldState, boolean isMoving) {
        if (!world.isRemote) {
            world.getPendingBlockTicks().scheduleTick(pos, this, 160);
        }
    }

    @Override
    public void tick(BlockState state, ServerWorld world, BlockPos pos, Random random) {
        if (world.getBlockState(pos).getBlock() == this) {
            world.setBlockState(pos, Blocks.AIR.getDefaultState(), 3);
        }
    }
}
