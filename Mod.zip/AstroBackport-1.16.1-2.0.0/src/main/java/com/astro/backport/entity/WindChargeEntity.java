package com.astro.backport.entity;

import com.astro.backport.ModEntities;
import com.astro.backport.ModItems;

import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.block.AbstractButtonBlock;
import net.minecraft.block.BlockState;
import net.minecraft.block.DoorBlock;
import net.minecraft.block.FenceGateBlock;
import net.minecraft.block.LeverBlock;
import net.minecraft.block.TrapDoorBlock;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.item.ItemEntity;
import net.minecraft.entity.item.BoatEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.ProjectileItemEntity;
import net.minecraft.item.Item;
import net.minecraft.network.IPacket;
import net.minecraft.particles.ParticleTypes;
import net.minecraft.util.DamageSource;
import net.minecraft.util.Hand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvents;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockRayTraceResult;
import net.minecraft.util.math.EntityRayTraceResult;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.vector.Vector3d;
import net.minecraft.world.World;
import net.minecraft.world.server.ServerWorld;
import net.minecraftforge.fml.network.NetworkHooks;

/** Wind charge: no gravity, bursts on impact (knockback only, no block damage), toggles doors/levers/buttons. */
public class WindChargeEntity extends ProjectileItemEntity {
    private static final double RADIUS = 3.0D;
    private LivingEntity thrower;

    public WindChargeEntity(EntityType<? extends WindChargeEntity> type, World world) {
        super(type, world);
    }

    public WindChargeEntity(World world, LivingEntity shooter) {
        super(ModEntities.WIND_CHARGE, shooter, world);
        this.thrower = shooter;
    }

    @Override
    protected Item getDefaultItem() {
        return ModItems.WIND_CHARGE;
    }

    @Override
    protected float getGravityVelocity() {
        return 0.0F;
    }

    @Override
    public IPacket<?> createSpawnPacket() {
        return NetworkHooks.getEntitySpawningPacket(this);
    }

    @Override
    public void tick() {
        super.tick();
        if (world.isRemote) {
            world.addParticle(ParticleTypes.CLOUD, getPosX(), getPosY(), getPosZ(), 0.0D, 0.0D, 0.0D);
        } else if (ticksExisted > 80) {
            remove();
        }
    }

    @Override
    protected void onImpact(RayTraceResult result) {
        if (world.isRemote) {
            return;
        }
        Vector3d center = result.getHitVec();
        if (result.getType() == RayTraceResult.Type.ENTITY) {
            Entity hit = ((EntityRayTraceResult) result).getEntity();
            hit.attackEntityFrom(DamageSource.causeThrownDamage(this, thrower), 1.0F);
        } else if (result.getType() == RayTraceResult.Type.BLOCK && thrower instanceof PlayerEntity) {
            BlockRayTraceResult blockHit = (BlockRayTraceResult) result;
            BlockState state = world.getBlockState(blockHit.getPos());
            Block block = state.getBlock();
            boolean toggle = block instanceof LeverBlock || block instanceof AbstractButtonBlock
                || (block instanceof DoorBlock && block != Blocks.IRON_DOOR)
                || (block instanceof TrapDoorBlock && block != Blocks.IRON_TRAPDOOR)
                || block instanceof FenceGateBlock;
            if (toggle) {
                state.onBlockActivated(world, (PlayerEntity) thrower, Hand.MAIN_HAND, blockHit);
            }
        }
        AxisAlignedBB box = new AxisAlignedBB(center.x - RADIUS, center.y - RADIUS, center.z - RADIUS,
            center.x + RADIUS, center.y + RADIUS, center.z + RADIUS);
        for (Entity entity : world.getEntitiesWithinAABB(Entity.class, box)) {
            if (entity == this || !(entity instanceof LivingEntity || entity instanceof ItemEntity || entity instanceof BoatEntity)) {
                continue;
            }
            Vector3d offset = new Vector3d(entity.getPosX(), entity.getPosY() + entity.getHeight() * 0.5D, entity.getPosZ()).subtract(center);
            double distance = offset.length();
            if (distance > RADIUS) {
                continue;
            }
            Vector3d direction = distance < 0.01D ? new Vector3d(0.0D, 1.0D, 0.0D) : offset.scale(1.0D / distance);
            double falloff = 1.0D - distance / RADIUS;
            double power = 1.5D * falloff + 0.2D;
            entity.setMotion(entity.getMotion().add(direction.x * power, direction.y * power + 0.3D * falloff, direction.z * power));
            entity.velocityChanged = true;
        }
        world.playSound(null, center.x, center.y, center.z, SoundEvents.ENTITY_GENERIC_EXPLODE, SoundCategory.NEUTRAL, 0.5F, 1.7F);
        ((ServerWorld) world).spawnParticle(ParticleTypes.POOF, center.x, center.y, center.z, 14, 0.4D, 0.4D, 0.4D, 0.08D);
        remove();
    }
}
