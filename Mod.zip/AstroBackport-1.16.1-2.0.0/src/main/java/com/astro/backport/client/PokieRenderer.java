package com.astro.backport.client;

import com.astro.backport.AstroBackport;
import com.astro.backport.entity.PokieSnowmanEntity;
import com.mojang.blaze3d.matrix.MatrixStack;

import net.minecraft.client.renderer.entity.EntityRendererManager;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.model.SnowManModel;
import net.minecraft.util.ResourceLocation;

/** Same model as the vanilla snow golem, own texture (pumpkin head painted in). */
public class PokieRenderer extends MobRenderer<PokieSnowmanEntity, SnowManModel<PokieSnowmanEntity>> {
    private static final ResourceLocation TEXTURE = new ResourceLocation(AstroBackport.MODID, "textures/entity/pokie_snowman.png");

    public PokieRenderer(EntityRendererManager manager) {
        super(manager, new SnowManModel<PokieSnowmanEntity>(), 0.5F);
    }

    @Override
    protected void preRenderCallback(PokieSnowmanEntity entity, MatrixStack matrixStack, float partialTickTime) {
        if (entity.isPokieSitting()) {
            matrixStack.scale(1.0F, 0.8F, 1.0F);
        }
    }

    @Override
    public ResourceLocation getEntityTexture(PokieSnowmanEntity entity) {
        return TEXTURE;
    }
}
