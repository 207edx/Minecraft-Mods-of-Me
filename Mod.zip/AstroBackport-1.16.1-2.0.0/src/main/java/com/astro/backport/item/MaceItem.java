package com.astro.backport.item;

import com.astro.backport.ModEnchants;
import com.astro.backport.ModItems;
import com.astro.backport.util.AttrUtil;
import com.google.common.collect.Multimap;

import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentType;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.attributes.Attribute;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.inventory.EquipmentSlotType;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

/** Mace: attack damage 6, attack speed 0.6, 500 durability. Smash logic lives in MaceEvents. */
public class MaceItem extends Item {
    private Multimap<Attribute, AttributeModifier> modifiers;

    public MaceItem(Item.Properties properties) {
        super(properties);
    }

    @Override
    public Multimap<Attribute, AttributeModifier> getAttributeModifiers(EquipmentSlotType slot) {
        if (slot != EquipmentSlotType.MAINHAND) {
            return super.getAttributeModifiers(slot);
        }
        if (modifiers == null) {
            modifiers = AttrUtil.weapon(5.0D, -3.4D);
        }
        return modifiers;
    }

    @Override
    public boolean hitEntity(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        stack.damageItem(1, attacker, entity -> entity.sendBreakAnimation(EquipmentSlotType.MAINHAND));
        return true;
    }

    @Override
    public int getItemEnchantability() {
        return 15;
    }

    @Override
    public boolean getIsRepairable(ItemStack toRepair, ItemStack repair) {
        return repair.getItem() == ModItems.BREEZE_ROD;
    }

    @Override
    public boolean canApplyAtEnchantingTable(ItemStack stack, Enchantment enchantment) {
        return enchantment.type == EnchantmentType.BREAKABLE
            || enchantment.type == ModEnchants.MACE_TYPE
            || enchantment == Enchantments.SMITE
            || enchantment == Enchantments.BANE_OF_ARTHROPODS
            || enchantment == Enchantments.FIRE_ASPECT;
    }
}
