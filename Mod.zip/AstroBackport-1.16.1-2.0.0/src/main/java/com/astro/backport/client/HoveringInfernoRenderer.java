package com.astro.backport.client;

import com.astro.backport.AstroBackport;
import com.astro.backport.entity.HoveringInfernoEntity;
import com.mojang.blaze3d.matrix.MatrixStack;

import net.minecraft.client.renderer.entity.EntityRendererManager;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.BlockPos;

public class HoveringInfernoRenderer extends MobRenderer<HoveringInfernoEntity, HoveringInfernoModel> {
    private static final ResourceLocation TEXTURE = new ResourceLocation(AstroBackport.MODID, "textures/entity/hovering_inferno.png");

    public HoveringInfernoRenderer(EntityRendererManager manager) {
        super(manager, new HoveringInfernoModel(), 1.4F);
    }

    @Override
    protected void preRenderCallback(HoveringInfernoEntity entity, MatrixStack matrixStack, float partialTickTime) {
        matrixStack.scale(1.3F, 1.3F, 1.3F);
    }

    @Override
    protected int getBlockLight(HoveringInfernoEntity entity, BlockPos pos) {
        return 15;
    }

    @Override
    public ResourceLocation getEntityTexture(HoveringInfernoEntity entity) {
        return TEXTURE;
    }
}
