package com.astro.backport;

import com.astro.backport.client.ClientSetup;
import com.astro.backport.config.AstroConfig;
import com.astro.backport.net.Network;
import com.astro.backport.util.AttrUtil;

import net.minecraft.entity.EntityType;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/** Astro Backport 2.0.0 for Minecraft 1.16.1 / Forge 32.0.108. */
@Mod(AstroBackport.MODID)
public final class AstroBackport {
    public static final String MODID = "astrobackport";
    public static final Logger LOGGER = LogManager.getLogger(MODID);

    public AstroBackport() {
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();
        modBus.addListener(this::commonSetup);
        modBus.addListener(this::clientSetup);
        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, AstroConfig.SPEC);
    }

    private void commonSetup(FMLCommonSetupEvent event) {
        Network.init();
        event.enqueueWork(() -> {
            AttrUtil.copyAttributes(ModEntities.BREEZE, EntityType.BLAZE);
            AttrUtil.copyAttributes(ModEntities.HEAVY_IRON_GOLEM, EntityType.IRON_GOLEM);
            AttrUtil.copyAttributes(ModEntities.HOVERING_INFERNO, EntityType.BLAZE);
            AttrUtil.copyAttributes(ModEntities.POKIE_SNOWMAN, EntityType.SNOW_GOLEM);
        });
    }

    private void clientSetup(FMLClientSetupEvent event) {
        DistExecutor.runWhenOn(Dist.CLIENT, () -> ClientSetup::registerRenderers);
    }
}
