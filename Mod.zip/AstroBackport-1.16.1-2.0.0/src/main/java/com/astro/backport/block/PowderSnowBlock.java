package com.astro.backport.block;

import com.astro.backport.event.FreezeManager;
import com.astro.backport.util.AstroUtil;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.inventory.EquipmentSlotType;
import net.minecraft.item.Items;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.vector.Vector3d;
import net.minecraft.world.World;

/** Powder snow: no collision, entities sink and are slowed, long exposure freezes. Leather boots walk on top. */
public class PowderSnowBlock extends Block {
    public PowderSnowBlock(Block.Properties properties) {
        super(properties);
    }

    @Override
    public void onEntityCollision(BlockState state, World world, BlockPos pos, Entity entity) {
        if (AstroUtil.freezeImmune(entity)) {
            return;
        }
        if (entity instanceof LivingEntity && !entity.isSneaking()
            && ((LivingEntity) entity).getItemStackFromSlot(EquipmentSlotType.FEET).getItem() == Items.LEATHER_BOOTS
            && entity.getPosY() >= pos.getY() + 0.6D) {
            Vector3d motion = entity.getMotion();
            entity.setMotion(motion.x, Math.max(motion.y, 0.0D), motion.z);
            entity.setPosition(entity.getPosX(), pos.getY() + 1.0D, entity.getPosZ());
            entity.onGround = true;
            entity.fallDistance = 0.0F;
            return;
        }
        entity.setMotionMultiplier(state, new Vector3d(0.9D, 1.5D, 0.9D));
        entity.fallDistance = 0.0F;
        if (!world.isRemote) {
            if (entity.isBurning()) {
                entity.extinguish();
            }
            FreezeManager.touch(entity);
        }
    }
}
