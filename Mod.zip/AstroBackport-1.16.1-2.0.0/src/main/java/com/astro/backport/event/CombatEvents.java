package com.astro.backport.event;

import com.astro.backport.AstroBackport;
import com.astro.backport.ModEnchants;
import com.astro.backport.item.MaceItem;
import com.astro.backport.item.NetherTridentItem;
import com.astro.backport.item.SpearItem;
import com.astro.backport.util.AttrUtil;

import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.EffectInstance;
import net.minecraft.potion.Effects;
import net.minecraft.util.CombatRules;
import net.minecraft.util.DamageSource;
import net.minecraft.util.Hand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvents;
import net.minecraft.util.math.vector.Vector3d;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.player.AttackEntityEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Mace smash attack, Breach/Density/Wind Burst, Spear lunge, Nether Trident enchantments. */
@Mod.EventBusSubscriber(modid = AstroBackport.MODID)
public final class CombatEvents {
    private CombatEvents() {}

    @SubscribeEvent
    public static void onHurt(LivingHurtEvent event) {
        Entity source = event.getSource().getTrueSource();
        if (!(source instanceof LivingEntity) || event.getSource().getImmediateSource() != source) {
            return;
        }
        LivingEntity attacker = (LivingEntity) source;
        LivingEntity target = event.getEntityLiving();
        ItemStack held = attacker.getHeldItemMainhand();
        if (held.getItem() instanceof MaceItem) {
            smash(event, attacker, target, held);
        } else if (held.getItem() instanceof NetherTridentItem) {
            int searing = EnchantmentHelper.getEnchantmentLevel(ModEnchants.SEARING_EDGE, held);
            if (searing > 0) {
                event.setAmount(event.getAmount() + 1.5F * searing);
                target.setFire(3 * searing);
            }
        }
    }

    private static void smash(LivingHurtEvent event, LivingEntity attacker, LivingEntity target, ItemStack mace) {
        float fall = attacker.fallDistance;
        if (fall <= 1.5F || attacker.isElytraFlying()) {
            return;
        }
        float bonus = fall <= 3.0F ? 4.0F * fall : (fall <= 8.0F ? 12.0F + 2.0F * (fall - 3.0F) : 22.0F + (fall - 8.0F));
        int density = EnchantmentHelper.getEnchantmentLevel(ModEnchants.DENSITY, mace);
        int breach = EnchantmentHelper.getEnchantmentLevel(ModEnchants.BREACH, mace);
        int windBurst = EnchantmentHelper.getEnchantmentLevel(ModEnchants.WIND_BURST, mace);
        bonus += 0.5F * density * fall;
        float amount = event.getAmount() + bonus;
        if (breach > 0) {
            // Breach: each level removes 15% of the armor's effect. Compensate for the armor applied afterwards.
            float armor = target.getTotalArmorValue();
            float toughness = (float) AttrUtil.get(target, "generic.armor_toughness");
            float reduced = CombatRules.getDamageAfterAbsorb(amount, armor, toughness);
            float breached = CombatRules.getDamageAfterAbsorb(amount, armor * (1.0F - 0.15F * breach), toughness * (1.0F - 0.15F * breach));
            if (reduced > 0.0F) {
                amount = amount * (breached / reduced);
            }
        }
        event.setAmount(amount);

        // Shockwave knocks nearby entities away.
        for (LivingEntity near : attacker.world.getEntitiesWithinAABB(LivingEntity.class, target.getBoundingBox().grow(3.5D, 1.0D, 3.5D))) {
            if (near == attacker || near == target) {
                continue;
            }
            Vector3d away = near.getPositionVec().subtract(target.getPositionVec());
            if (away.length() < 0.01D) {
                continue;
            }
            away = away.normalize();
            double power = Math.min(1.5D, 0.5D + fall * 0.08D);
            near.addVelocity(away.x * power, 0.3D, away.z * power);
            near.velocityChanged = true;
        }
        attacker.world.playSound(null, target.getPosX(), target.getPosY(), target.getPosZ(),
            fall > 5.0F ? SoundEvents.BLOCK_ANVIL_LAND : SoundEvents.ENTITY_IRON_GOLEM_ATTACK, SoundCategory.PLAYERS, 1.0F, 0.6F);
        if (windBurst > 0) {
            attacker.setMotion(attacker.getMotion().x, 0.7D + 0.3D * windBurst, attacker.getMotion().z);
            attacker.velocityChanged = true;
            attacker.world.playSound(null, attacker.getPosX(), attacker.getPosY(), attacker.getPosZ(),
                SoundEvents.ENTITY_ENDER_DRAGON_FLAP, SoundCategory.PLAYERS, 1.0F, 1.4F);
        }
        attacker.fallDistance = 0.0F; // no fall damage after a smash
    }

    @SubscribeEvent
    public static void onAttack(AttackEntityEvent event) {
        PlayerEntity player = event.getPlayer();
        ItemStack held = player.getHeldItemMainhand();
        if (!player.world.isRemote && held.getItem() instanceof SpearItem) {
            SpearItem.tryLunge(player, held);
        }
    }

    /** Infernal Ward: fire resistance while the trident is held. */
    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        PlayerEntity player = event.player;
        if (event.phase != TickEvent.Phase.END || player.world.isRemote || player.ticksExisted % 10 != 0) {
            return;
        }
        for (Hand hand : Hand.values()) {
            ItemStack stack = player.getHeldItem(hand);
            if (stack.getItem() instanceof NetherTridentItem) {
                if (EnchantmentHelper.getEnchantmentLevel(ModEnchants.INFERNAL_WARD, stack) > 0) {
                    player.addPotionEffect(new EffectInstance(Effects.FIRE_RESISTANCE, 60, 0, false, false, true));
                }
                int speed = EnchantmentHelper.getEnchantmentLevel(ModEnchants.SCORCH_VELOCITY, stack);
                if (speed > 0 && player.isInLava()) {
                    player.addPotionEffect(new EffectInstance(Effects.SPEED, 40, speed - 1, false, false, false));
                }
            }
        }
    }
}
