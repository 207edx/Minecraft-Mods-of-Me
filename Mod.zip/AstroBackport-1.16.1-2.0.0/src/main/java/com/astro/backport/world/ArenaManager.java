package com.astro.backport.world;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.astro.backport.AstroBackport;
import com.astro.backport.ModEntities;
import com.astro.backport.config.AstroConfig;
import com.astro.backport.entity.HoveringInfernoEntity;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.nbt.CompoundNBT;
import net.minecraft.nbt.ListNBT;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.server.ServerWorld;
import net.minecraft.world.storage.WorldSavedData;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Builds a boss arena (and spawns a single Hovering Inferno) the first time a player explores a
 * Nether fortress. Fortress detection counts nether-brick blocks around the player.
 */
@Mod.EventBusSubscriber(modid = AstroBackport.MODID)
public final class ArenaManager {
    private static final int RADIUS = 13;
    private static final int HEIGHT = 20;
    private static final int PER_TICK = 1500;
    private static final List<Job> JOBS = new ArrayList<Job>();

    private ArenaManager() {}

    public static final class Data extends WorldSavedData {
        public static final String NAME = "astrobackport_arenas";
        public final List<int[]> arenas = new ArrayList<int[]>(); // x, y, z, defeated(0/1)

        public Data() {
            super(NAME);
        }

        @Override
        public void read(CompoundNBT nbt) {
            arenas.clear();
            ListNBT list = nbt.getList("Arenas", 10);
            for (int i = 0; i < list.size(); i++) {
                CompoundNBT tag = list.getCompound(i);
                arenas.add(new int[] {tag.getInt("X"), tag.getInt("Y"), tag.getInt("Z"), tag.getInt("D")});
            }
        }

        @Override
        public CompoundNBT write(CompoundNBT nbt) {
            ListNBT list = new ListNBT();
            for (int[] a : arenas) {
                CompoundNBT tag = new CompoundNBT();
                tag.putInt("X", a[0]);
                tag.putInt("Y", a[1]);
                tag.putInt("Z", a[2]);
                tag.putInt("D", a[3]);
                list.add(tag);
            }
            nbt.put("Arenas", list);
            return nbt;
        }
    }

    private static final class Job {
        final ServerWorld world;
        final BlockPos center;
        int index;

        Job(ServerWorld world, BlockPos center) {
            this.world = world;
            this.center = center;
        }
    }

    private static Data data(ServerWorld world) {
        return world.getSavedData().getOrCreate(Data::new, Data.NAME);
    }

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        PlayerEntity player = event.player;
        if (event.phase != TickEvent.Phase.END || player.world.isRemote || player.ticksExisted % 60 != 0
            || !AstroConfig.CFG.fortressArenas.get()) {
            return;
        }
        ServerWorld world = (ServerWorld) player.world;
        BlockPos pos = new BlockPos(player.getPosX(), player.getPosY(), player.getPosZ());
        if (world.getBiome(pos).getCategory() != Biome.Category.NETHER) {
            return;
        }
        Data data = data(world);
        if (data.arenas.size() >= AstroConfig.CFG.maxArenas.get()) {
            return;
        }
        double spacing = AstroConfig.CFG.arenaSpacing.get();
        for (int[] a : data.arenas) {
            double dx = a[0] - pos.getX();
            double dz = a[2] - pos.getZ();
            if (dx * dx + dz * dz < spacing * spacing) {
                return;
            }
        }
        for (Job job : JOBS) {
            if (job.world == world) {
                return;
            }
        }
        if (!inFortress(world, pos)) {
            return;
        }
        data.arenas.add(new int[] {pos.getX(), pos.getY(), pos.getZ(), 0});
        data.markDirty();
        JOBS.add(new Job(world, pos));
    }

    private static boolean inFortress(World world, BlockPos center) {
        int count = 0;
        boolean fence = false;
        for (int dx = -6; dx <= 6; dx++) {
            for (int dy = -3; dy <= 3; dy++) {
                for (int dz = -6; dz <= 6; dz++) {
                    Block block = world.getBlockState(center.add(dx, dy, dz)).getBlock();
                    if (block == Blocks.NETHER_BRICKS || block == Blocks.NETHER_BRICK_STAIRS || block == Blocks.NETHER_BRICK_SLAB) {
                        count++;
                    } else if (block == Blocks.NETHER_BRICK_FENCE) {
                        count++;
                        fence = true;
                    }
                }
            }
        }
        return count >= 70 && fence;
    }

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || JOBS.isEmpty()) {
            return;
        }
        Iterator<Job> iterator = JOBS.iterator();
        while (iterator.hasNext()) {
            Job job = iterator.next();
            int side = RADIUS * 2 + 1;
            int total = side * side * HEIGHT;
            int end = Math.min(total, job.index + PER_TICK);
            for (; job.index < end; job.index++) {
                int i = job.index;
                int layer = i % HEIGHT;
                int dz = (i / HEIGHT) % side - RADIUS;
                int dx = i / (HEIGHT * side) - RADIUS;
                double dist = Math.sqrt(dx * dx + dz * dz);
                if (dist > RADIUS) {
                    continue;
                }
                BlockPos pos = job.center.add(dx, layer - 1, dz);
                if (!job.world.isBlockLoaded(pos)) {
                    continue;
                }
                BlockState state = layer == 0 ? floor(dist) : Blocks.AIR.getDefaultState();
                job.world.setBlockState(pos, state, 2);
            }
            if (job.index >= total) {
                finish(job);
                iterator.remove();
            }
        }
    }

    private static BlockState floor(double dist) {
        if (dist <= 3.0D) {
            return Blocks.OBSIDIAN.getDefaultState();
        }
        if (dist >= 5.0D && dist <= 6.0D) {
            return Blocks.MAGMA_BLOCK.getDefaultState();
        }
        if (dist >= 9.0D && dist <= 11.0D) {
            return Blocks.RED_NETHER_BRICKS.getDefaultState();
        }
        return Blocks.NETHER_BRICKS.getDefaultState();
    }

    private static void finish(Job job) {
        for (int k = 0; k < 8; k++) {
            double angle = k * Math.PI / 4.0D;
            int px = job.center.getX() + (int) Math.round(Math.cos(angle) * 10.0D);
            int pz = job.center.getZ() + (int) Math.round(Math.sin(angle) * 10.0D);
            for (int h = 0; h < 7; h++) {
                job.world.setBlockState(new BlockPos(px, job.center.getY() + h, pz), Blocks.NETHER_BRICK_FENCE.getDefaultState(), 2);
            }
            job.world.setBlockState(new BlockPos(px, job.center.getY() + 7, pz), Blocks.NETHERRACK.getDefaultState(), 2);
            job.world.setBlockState(new BlockPos(px, job.center.getY() + 8, pz), Blocks.FIRE.getDefaultState(), 2);
        }
        HoveringInfernoEntity boss = ModEntities.HOVERING_INFERNO.create(job.world);
        if (boss != null) {
            boss.setLocationAndAngles(job.center.getX() + 0.5D, job.center.getY() + 7.0D, job.center.getZ() + 0.5D, 0.0F, 0.0F);
            job.world.addEntity(boss);
        }
    }

    @SubscribeEvent
    public static void onDeath(LivingDeathEvent event) {
        if (!(event.getEntityLiving() instanceof HoveringInfernoEntity) || event.getEntityLiving().world.isRemote) {
            return;
        }
        ServerWorld world = (ServerWorld) event.getEntityLiving().world;
        Data data = data(world);
        for (int[] a : data.arenas) {
            double dx = a[0] - event.getEntityLiving().getPosX();
            double dz = a[2] - event.getEntityLiving().getPosZ();
            if (dx * dx + dz * dz < 60.0D * 60.0D) {
                a[3] = 1;
            }
        }
        data.markDirty();
    }
}
