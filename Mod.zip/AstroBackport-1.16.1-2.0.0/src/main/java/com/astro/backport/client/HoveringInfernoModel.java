package com.astro.backport.client;

import com.astro.backport.entity.HoveringInfernoEntity;
import com.mojang.blaze3d.matrix.MatrixStack;
import com.mojang.blaze3d.vertex.IVertexBuilder;

import net.minecraft.client.renderer.entity.model.EntityModel;
import net.minecraft.client.renderer.model.ModelRenderer;

/** Glowing core ringed by three orbits of flame rods, with four shield plates when shielded. Texture 128x64. */
public class HoveringInfernoModel extends EntityModel<HoveringInfernoEntity> {
    private final ModelRenderer core;
    private final ModelRenderer[] rods = new ModelRenderer[12];
    private final ModelRenderer[] plates = new ModelRenderer[4];
    private boolean shield;

    public HoveringInfernoModel() {
        this.textureWidth = 128;
        this.textureHeight = 64;
        core = new ModelRenderer(this, 0, 0);
        core.addBox(-6.0F, -6.0F, -6.0F, 12.0F, 12.0F, 12.0F);
        core.setRotationPoint(0.0F, 12.0F, 0.0F);
        for (int i = 0; i < rods.length; i++) {
            rods[i] = new ModelRenderer(this, 0, 32);
            rods[i].addBox(0.0F, 0.0F, 0.0F, 2.0F, 8.0F, 2.0F);
        }
        for (int i = 0; i < plates.length; i++) {
            plates[i] = new ModelRenderer(this, 64, 0);
            plates[i].addBox(-6.0F, -8.0F, 0.0F, 12.0F, 16.0F, 2.0F);
        }
    }

    @Override
    public void setRotationAngles(HoveringInfernoEntity entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        core.rotateAngleY = netHeadYaw * ((float) Math.PI / 180F);
        core.rotateAngleX = headPitch * ((float) Math.PI / 180F);
        for (int i = 0; i < 4; i++) {
            float a = ageInTicks * 0.1F + i * (float) Math.PI / 2.0F;
            place(rods[i], a, 9.0F, 7.0F + (float) Math.cos((i * 2 + ageInTicks) * 0.25F));
            float b = -ageInTicks * 0.08F + i * (float) Math.PI / 2.0F + (float) Math.PI / 4.0F;
            place(rods[4 + i], b, 12.0F, 16.0F + (float) Math.cos((i * 2 + ageInTicks) * 0.25F));
            float c = ageInTicks * 0.12F + i * (float) Math.PI / 2.0F;
            place(rods[8 + i], c, 7.0F, -1.0F + (float) Math.cos((i * 2 + ageInTicks) * 0.25F));
        }
        for (int i = 0; i < 4; i++) {
            float a = ageInTicks * 0.05F + i * (float) Math.PI / 2.0F;
            plates[i].setRotationPoint((float) Math.cos(a) * 17.0F, 12.0F, (float) Math.sin(a) * 17.0F);
            plates[i].rotateAngleY = -a + (float) Math.PI / 2.0F;
        }
        shield = entity.isShielded();
    }

    private static void place(ModelRenderer rod, float angle, float radius, float y) {
        rod.setRotationPoint((float) Math.cos(angle) * radius, y, (float) Math.sin(angle) * radius);
    }

    @Override
    public void render(MatrixStack matrixStack, IVertexBuilder buffer, int light, int overlay, float red, float green, float blue, float alpha) {
        core.render(matrixStack, buffer, light, overlay, red, green, blue, alpha);
        for (ModelRenderer rod : rods) {
            rod.render(matrixStack, buffer, light, overlay, red, green, blue, alpha);
        }
        if (shield) {
            for (ModelRenderer plate : plates) {
                plate.render(matrixStack, buffer, light, overlay, red, green, blue, alpha);
            }
        }
    }
}
