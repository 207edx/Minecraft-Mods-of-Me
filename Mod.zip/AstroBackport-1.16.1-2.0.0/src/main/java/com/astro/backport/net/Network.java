package com.astro.backport.net;

import java.util.function.Supplier;

import com.astro.backport.AstroBackport;
import com.astro.backport.client.ClientLeash;

import net.minecraft.network.PacketBuffer;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.fml.network.NetworkEvent;
import net.minecraftforge.fml.network.NetworkRegistry;
import net.minecraftforge.fml.network.simple.SimpleChannel;

/** Client sync for leash lines on boats and minecarts. */
public final class Network {
    private static final String VERSION = "2";
    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
        new ResourceLocation(AstroBackport.MODID, "main"),
        () -> VERSION,
        VERSION::equals,
        VERSION::equals
    );

    private static boolean initialized;

    private Network() {}

    public static void init() {
        if (initialized) {
            return;
        }
        initialized = true;
        CHANNEL.registerMessage(0, LeashSync.class, LeashSync::encode, LeashSync::decode, LeashSync::handle);
        CHANNEL.registerMessage(1, SpearJab.class, SpearJab::encode, SpearJab::decode, SpearJab::handle);
    }

    /** holderId is -1 when the custom leash is removed. */
    public static final class LeashSync {
        public final int entityId;
        public final int holderId;

        public LeashSync(int entityId, int holderId) {
            this.entityId = entityId;
            this.holderId = holderId;
        }

        private static void encode(LeashSync message, PacketBuffer buffer) {
            buffer.writeInt(message.entityId);
            buffer.writeInt(message.holderId);
        }

        private static LeashSync decode(PacketBuffer buffer) {
            return new LeashSync(buffer.readInt(), buffer.readInt());
        }

        private static void handle(LeashSync message, Supplier<NetworkEvent.Context> contextSupplier) {
            NetworkEvent.Context context = contextSupplier.get();
            context.enqueueWork(() -> DistExecutor.runWhenOn(Dist.CLIENT,
                () -> () -> ClientLeash.set(message.entityId, message.holderId)));
            context.setPacketHandled(true);
        }
    }

    /** Client -> server: spear jab on an entity beyond vanilla reach. */
    public static final class SpearJab {
        public final int targetId;

        public SpearJab(int targetId) {
            this.targetId = targetId;
        }

        private static void encode(SpearJab message, PacketBuffer buffer) {
            buffer.writeInt(message.targetId);
        }

        private static SpearJab decode(PacketBuffer buffer) {
            return new SpearJab(buffer.readInt());
        }

        private static void handle(SpearJab message, Supplier<NetworkEvent.Context> contextSupplier) {
            NetworkEvent.Context context = contextSupplier.get();
            context.enqueueWork(() -> {
                net.minecraft.entity.player.ServerPlayerEntity player = context.getSender();
                if (player == null || !(player.getHeldItemMainhand().getItem() instanceof com.astro.backport.item.SpearItem)) {
                    return;
                }
                net.minecraft.entity.Entity target = player.world.getEntityByID(message.targetId);
                if (target == null || !target.isAlive() || player.getDistance(target) > com.astro.backport.item.SpearItem.JAB_REACH + 1.0D
                    || !player.canEntityBeSeen(target)) {
                    return;
                }
                com.astro.backport.item.SpearItem.tryLunge(player, player.getHeldItemMainhand());
                player.attackTargetEntityWithCurrentItem(target);
                player.swingArm(net.minecraft.util.Hand.MAIN_HAND);
            });
            context.setPacketHandled(true);
        }
    }
}
