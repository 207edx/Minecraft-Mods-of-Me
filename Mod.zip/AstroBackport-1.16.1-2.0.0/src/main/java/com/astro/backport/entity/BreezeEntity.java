package com.astro.backport.entity;

import java.util.EnumSet;

import com.astro.backport.util.AttrUtil;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.entity.ai.goal.HurtByTargetGoal;
import net.minecraft.entity.ai.goal.LookAtGoal;
import net.minecraft.entity.ai.goal.LookRandomlyGoal;
import net.minecraft.entity.ai.goal.NearestAttackableTargetGoal;
import net.minecraft.entity.ai.goal.WaterAvoidingRandomWalkingGoal;
import net.minecraft.entity.monster.MonsterEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.DamageSource;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.SoundEvents;
import net.minecraft.util.math.vector.Vector3d;
import net.minecraft.world.World;

/** Breeze: the blue Blaze variant. Fires wind charges and leaps. Created when a Blaze touches snow in the overworld. */
public class BreezeEntity extends MonsterEntity {
    public BreezeEntity(EntityType<? extends BreezeEntity> type, World world) {
        super(type, world);
        this.experienceValue = 10;
        AttrUtil.setBase(this, "generic.max_health", 30.0D);
        AttrUtil.setBase(this, "generic.follow_range", 24.0D);
        AttrUtil.setBase(this, "generic.movement_speed", 0.25D);
        this.setHealth(30.0F);
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(1, new BreezeAttackGoal(this));
        goalSelector.addGoal(3, new WaterAvoidingRandomWalkingGoal(this, 1.0D));
        goalSelector.addGoal(4, new LookAtGoal(this, PlayerEntity.class, 8.0F));
        goalSelector.addGoal(5, new LookRandomlyGoal(this));
        targetSelector.addGoal(1, new HurtByTargetGoal(this));
        targetSelector.addGoal(2, new NearestAttackableTargetGoal<PlayerEntity>(this, PlayerEntity.class, true));
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return SoundEvents.ENTITY_BLAZE_AMBIENT;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.ENTITY_BLAZE_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.ENTITY_BLAZE_DEATH;
    }

    static final class BreezeAttackGoal extends Goal {
        private final BreezeEntity breeze;
        private int shootCooldown = 40;
        private int leapCooldown = 60;

        BreezeAttackGoal(BreezeEntity breeze) {
            this.breeze = breeze;
            setMutexFlags(EnumSet.of(Goal.Flag.MOVE, Goal.Flag.LOOK));
        }

        @Override
        public boolean shouldExecute() {
            LivingEntity target = breeze.getAttackTarget();
            return target != null && target.isAlive();
        }

        @Override
        public void tick() {
            LivingEntity target = breeze.getAttackTarget();
            if (target == null) {
                return;
            }
            breeze.getLookController().setLookPositionWithEntity(target, 30.0F, 30.0F);
            double distance = breeze.getDistance(target);
            if (distance > 9.0D) {
                breeze.getNavigator().tryMoveToEntityLiving(target, 1.0D);
            } else {
                breeze.getNavigator().clearPath();
            }
            if (--shootCooldown <= 0 && breeze.canEntityBeSeen(target) && distance < 20.0D) {
                shootCooldown = 50 + breeze.getRNG().nextInt(20);
                WindChargeEntity charge = new WindChargeEntity(breeze.world, breeze);
                Vector3d aim = new Vector3d(target.getPosX(), target.getPosY() + target.getHeight() * 0.5D, target.getPosZ())
                    .subtract(charge.getPosX(), charge.getPosY(), charge.getPosZ());
                charge.shoot(aim.x, aim.y, aim.z, 0.9F, 2.0F);
                breeze.world.addEntity(charge);
                breeze.playSound(SoundEvents.ENTITY_BLAZE_SHOOT, 1.0F, 1.6F);
            }
            if (--leapCooldown <= 0 && breeze.isOnGround()) {
                leapCooldown = 70 + breeze.getRNG().nextInt(60);
                Vector3d away = breeze.getPositionVec().subtract(target.getPositionVec());
                Vector3d side = new Vector3d(-away.z, 0.0D, away.x).normalize().scale(breeze.getRNG().nextBoolean() ? 0.4D : -0.4D);
                breeze.setMotion(side.x, 0.85D, side.z);
                breeze.velocityChanged = true;
            }
        }
    }
}
