package com.astro.backport.event;

import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.vector.Vector3d;

/** Rope physics: a taut lead pulls the target, lifts it when the holder glides, and makes it hop when the holder jumps. */
public final class LeashPhysics {
    public static final double ROPE = 3.5D;

    private LeashPhysics() {}

    public static void pull(PlayerEntity holder, Entity target) {
        Vector3d offset = holder.getPositionVec().subtract(target.getPositionVec());
        double distance = offset.length();
        if (distance <= ROPE || distance < 0.001D) {
            return;
        }
        Vector3d dir = offset.scale(1.0D / distance);
        double stretch = distance - ROPE;
        double acc = Math.min(0.35D, stretch * 0.06D);
        Vector3d motion = target.getMotion();

        if (holder.isElytraFlying()) {
            // Towed behind the glider: match its velocity and get lifted like a kite.
            Vector3d hv = holder.getMotion();
            motion = motion.scale(0.2D).add(hv.scale(0.8D)).add(dir.scale(acc));
            target.fallDistance = 0.0F;
        } else {
            double vertical = 0.0D;
            if (target.isOnGround() && dir.y > 0.45D && holder.getMotion().y > 0.05D) {
                vertical = 0.42D + Math.min(0.3D, stretch * 0.1D) - motion.y; // jump when the holder jumps
            } else if (target.isInWater() || target.hasNoGravity()) {
                vertical = dir.y * acc;
            } else if (!target.isOnGround() && dir.y > 0.0D) {
                vertical = dir.y * acc * 0.5D;
            }
            motion = motion.add(dir.x * acc, vertical, dir.z * acc);
        }
        target.setMotion(motion);
        target.velocityChanged = true;
    }
}
