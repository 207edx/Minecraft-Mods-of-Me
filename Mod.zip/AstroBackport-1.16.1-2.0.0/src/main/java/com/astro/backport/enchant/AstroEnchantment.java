package com.astro.backport.enchant;

import net.minecraft.enchantment.DamageEnchantment;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentType;
import net.minecraft.inventory.EquipmentSlotType;

/** Generic data-driven enchantment. group != 0 makes enchantments of the same group exclusive. */
public class AstroEnchantment extends Enchantment {
    private final int maxLevel;
    private final int minBase;
    private final int group;

    public AstroEnchantment(Enchantment.Rarity rarity, EnchantmentType type, EquipmentSlotType[] slots, int maxLevel, int minBase, int group) {
        super(rarity, type, slots);
        this.maxLevel = maxLevel;
        this.minBase = minBase;
        this.group = group;
    }

    @Override
    public int getMaxLevel() {
        return maxLevel;
    }

    @Override
    public int getMinEnchantability(int level) {
        return minBase + (level - 1) * 10;
    }

    @Override
    public int getMaxEnchantability(int level) {
        return getMinEnchantability(level) + 15;
    }

    @Override
    protected boolean canApplyTogether(Enchantment other) {
        if (other != this && group != 0) {
            if (other instanceof AstroEnchantment && ((AstroEnchantment) other).group == group) {
                return false;
            }
            if (other instanceof DamageEnchantment) {
                return false;
            }
        }
        return super.canApplyTogether(other);
    }
}
