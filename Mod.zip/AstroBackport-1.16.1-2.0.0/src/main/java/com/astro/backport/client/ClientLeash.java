package com.astro.backport.client;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/** Client-side entity ID mapping used to draw custom lead lines. */
public final class ClientLeash {
    public static final Map<Integer, Integer> MAP = new ConcurrentHashMap<Integer, Integer>();

    private ClientLeash() {}

    public static void set(int entityId, int holderId) {
        if (holderId < 0) {
            MAP.remove(entityId);
        } else {
            MAP.put(entityId, holderId);
        }
    }

    public static void removeEntity(int entityId) {
        MAP.remove(entityId);
    }

    public static void clear() {
        MAP.clear();
    }
}
