# Astro Backport 2.0.0 — Minecraft 1.16.1 / Forge 32.0.108

**Target lock (unchanged from your 1.1.3 project):** Minecraft 1.16.1 · Forge 32.0.108 · ForgeGradle 3.0.197 · MCP `snapshot 20200820-1.16.1` · JDK 8 · Gradle 4.10.3.

> **Build status: UNVERIFIED.** This is a source project. The session that wrote it could not reach the Forge Maven, so it has **not been compiled or run**. It was checked statically (syntax, MCP names, Forge 1.16.1 signatures). Build it, and if the compiler reports any error, send me the first full error block.

## Build
```
java -version        (must be 1.8.x)
gradle --version     (must be 4.10.3)
gradle clean build
```
Jar: `build/libs/AstroBackport-1.16.1-2.0.0.jar` (build.gradle now has `jar.finalizedBy('reobfJar')` so the jar is reobfuscated and runs outside the dev environment). Install on **client and server**.

## Features
| Feature | How it works |
|---|---|
| **Heavy Iron Golem** | New iron golems (not player-built) have a 4% chance (config) to become a 1.75x scale golem: 400 HP, armor 8, own texture. Drops a **Heavy Core** (+ iron). |
| **Mace** | Craft: Heavy Core above a Breeze Rod. Damage 6, speed 0.6, 500 durability, repaired with Breeze Rods. Smash attack when falling >1.5 blocks: +4/block (first 3), +2/block (next 5), +1/block after; no fall damage after a smash; shockwave knockback. |
| **Mace enchantments** | **Density** (extra damage per block fallen), **Breach** (reduces armor effect 15%/level), **Wind Burst** (launch upward after a smash). Also Smite, Bane, Fire Aspect, Unbreaking, Mending. Come from the enchanting table (random) and librarian trades. |
| **Breeze** | A Blaze that stays touching snow / snow layers / powder snow for 2 seconds in the overworld (not Nether/End) converts to a blue Breeze. It shoots wind charges and leaps. Drops **Breeze Rods**. |
| **Wind Charge** | Craft 1 Breeze Rod -> 4 Wind Charges. Throw it: no damage burst, knocks entities (and you) away, toggles doors, trapdoors, gates, levers, buttons. |
| **Leads** | Vanilla animals as usual, plus boats, minecarts, hostile mobs, villagers, fish. A taut lead drags the target; the holder jumping makes it hop; gliding with an Elytra tows it behind you (also for vanilla leashed animals). Sneak + right-click detaches. Recipes: string -> lead (from 1.1.3), saddle. |
| **Extra animal spawns** | Cows, sheep, pigs, chickens spawn in packs near players on grass (config: interval, chance, cap). |
| **Spear** | Wood/Stone/Iron/Gold/Diamond (item on the diagonal + sticks: `__M / _S_ / S__`), Netherite by smithing. Left-click jab reaches 4.5 blocks. Hold right-click and run into mobs for a charge attack (dismounts riders). **Lunge** enchantment dashes you forward on a jab (uses hunger). |
| **Powder Snow** | Craft 2 Snow Blocks + Snowball -> 2 Powder Snow. No collision: you sink, are slowed, fall damage is cancelled, long exposure freezes (slowness + damage). Leather boots let you walk on top. White fog when your head is inside. Snow golems, strays, polar bears, Pokie are immune. |
| **Pokie Snowman** | Build like an iron golem: 3 Powder Snow in a T (arms+shoulders), 1 Snow Block below the middle, carved pumpkin/jack-o-lantern last. Loyal pet of the builder: follows, right-click to sit/stand, heals 5 HP per Snowball, 40 HP, throws damaging snowballs, defends you. When you are attacked it turns the 3x3x3 air around you (not the ground block or your own cells) into temporary powder snow (8 s). |
| **Hovering Inferno** (Nether boss) | When a player explores a Nether fortress (detected by nether-brick count) an arena is carved/built and one boss spawns (max arenas + spacing in config). Phases: large fireballs, shield (invulnerable bursts), summons weak Blazes/Breezes, fire aura on contact, fire nova at low health. Boss bar. Drops the **Heart of the Nether**. Not respawned. |
| **Nether Trident** | Craft: Heart of the Nether over 2 Blaze Rods. Hold + release for an infernal dash (works in lava or in the Nether; riptide-style spin hit). Enchants: **Infernal Ward** (fire resistance while held), **Lava Sight** (clear vision in lava), **Scorch Velocity** (dash/lava speed), **Searing Edge** (damage + ignite). Table + librarian trades. |

## Testing commands
`/summon astrobackport:breeze`, `/summon astrobackport:heavy_iron_golem`, `/summon astrobackport:hovering_inferno`, `/summon astrobackport:pokie_snowman`, or use the spawn eggs in the **Astro Backport** creative tab.

## Known limits (honest)
- No world-generation of powder snow (craft it); the Nether arena is a heuristic (nether-brick count), not a true structure.
- Mace smash sound and wind-burst sound reuse vanilla sounds (1.16.1 has none for these).
- Breach is an approximation (scales damage before armor is applied).
- Netherite spear is not fire-proof.

## Texture pack
`AstroBackport-TexturePack.zip` contains the same textures (editable PNGs). Put it in `resourcepacks/` to override; entity textures keep the vanilla UV layouts (blaze 64x32, iron golem 128x128, snow golem 64x64, inferno 128x64).
