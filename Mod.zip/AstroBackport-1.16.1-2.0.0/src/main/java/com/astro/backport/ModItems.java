package com.astro.backport;

import com.astro.backport.item.MaceItem;
import com.astro.backport.item.NetherTridentItem;
import com.astro.backport.item.SpearItem;
import com.astro.backport.item.WindChargeItem;

import net.minecraft.block.Block;
import net.minecraft.item.BlockItem;
import net.minecraft.item.IItemTier;
import net.minecraft.item.Item;
import net.minecraft.item.ItemTier;
import net.minecraft.item.SpawnEggItem;

public final class ModItems {
    private static Item.Properties props() {
        return new Item.Properties().group(ModGroup.INSTANCE);
    }

    private static <T extends Item> T named(T item, String name) {
        item.setRegistryName(AstroBackport.MODID, name);
        return item;
    }

    private static SpearItem spear(String name, IItemTier tier, double damage, double speed) {
        return named(new SpearItem(tier, damage, speed, props()), name);
    }

    public static final Item HEAVY_CORE = named(new Item(props().maxStackSize(16)), "heavy_core");
    public static final Item BREEZE_ROD = named(new Item(props()), "breeze_rod");
    public static final Item WIND_CHARGE = named(new WindChargeItem(props()), "wind_charge");
    public static final Item MACE = named(new MaceItem(props().maxStackSize(1).maxDamage(500)), "mace");
    public static final Item HEART_OF_NETHER = named(new Item(props().maxStackSize(16)), "heart_of_nether");
    public static final Item NETHER_TRIDENT = named(new NetherTridentItem(props().maxStackSize(1).maxDamage(450)), "nether_trident");

    public static final Item WOODEN_SPEAR = spear("wooden_spear", ItemTier.WOOD, 3.0D, 1.5D);
    public static final Item STONE_SPEAR = spear("stone_spear", ItemTier.STONE, 4.0D, 1.3D);
    public static final Item IRON_SPEAR = spear("iron_spear", ItemTier.IRON, 5.0D, 1.2D);
    public static final Item GOLDEN_SPEAR = spear("golden_spear", ItemTier.GOLD, 3.0D, 1.5D);
    public static final Item DIAMOND_SPEAR = spear("diamond_spear", ItemTier.DIAMOND, 6.0D, 1.1D);
    public static final Item NETHERITE_SPEAR = spear("netherite_spear", ItemTier.NETHERITE, 7.0D, 1.0D);

    public static final Item POWDER_SNOW = named(new BlockItem(ModBlocks.POWDER_SNOW, props()), "powder_snow");

    public static final Item BREEZE_EGG = named(new SpawnEggItem(ModEntities.BREEZE, 0x6FD3F5, 0xE8FBFF, props()), "breeze_spawn_egg");
    public static final Item HEAVY_GOLEM_EGG = named(new SpawnEggItem(ModEntities.HEAVY_IRON_GOLEM, 0x3B3F46, 0xC26B2D, props()), "heavy_iron_golem_spawn_egg");
    public static final Item INFERNO_EGG = named(new SpawnEggItem(ModEntities.HOVERING_INFERNO, 0x4A0E0E, 0xFF8A1F, props()), "hovering_inferno_spawn_egg");
    public static final Item POKIE_EGG = named(new SpawnEggItem(ModEntities.POKIE_SNOWMAN, 0xDDF3FF, 0xE8801A, props()), "pokie_snowman_spawn_egg");

    private ModItems() {}

    public static Item[] all() {
        return new Item[] {HEAVY_CORE, BREEZE_ROD, WIND_CHARGE, MACE, HEART_OF_NETHER, NETHER_TRIDENT,
            WOODEN_SPEAR, STONE_SPEAR, IRON_SPEAR, GOLDEN_SPEAR, DIAMOND_SPEAR, NETHERITE_SPEAR,
            POWDER_SNOW, BREEZE_EGG, HEAVY_GOLEM_EGG, INFERNO_EGG, POKIE_EGG};
    }

    public static Block[] blocks() {
        return new Block[] {ModBlocks.POWDER_SNOW, ModBlocks.TEMPORARY_POWDER_SNOW};
    }
}
