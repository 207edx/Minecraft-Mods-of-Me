package com.astro.backport;

import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;

public final class ModGroup extends ItemGroup {
    public static final ModGroup INSTANCE = new ModGroup();

    private ModGroup() {
        super("astrobackport");
    }

    @Override
    public ItemStack createIcon() {
        return new ItemStack(ModItems.MACE);
    }
}
