package com.astro.backport;

import com.astro.backport.block.PowderSnowBlock;
import com.astro.backport.block.TemporaryPowderSnowBlock;

import net.minecraft.block.Block;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;

public final class ModBlocks {
    public static final Block POWDER_SNOW = new PowderSnowBlock(Block.Properties.create(Material.SNOW_BLOCK)
        .hardnessAndResistance(0.25F).sound(SoundType.SNOW).doesNotBlockMovement().notSolid())
        .setRegistryName(AstroBackport.MODID, "powder_snow");
    public static final Block TEMPORARY_POWDER_SNOW = new TemporaryPowderSnowBlock(Block.Properties.create(Material.SNOW_BLOCK)
        .hardnessAndResistance(0.25F).sound(SoundType.SNOW).doesNotBlockMovement().notSolid())
        .setRegistryName(AstroBackport.MODID, "temporary_powder_snow");

    private ModBlocks() {}
}
