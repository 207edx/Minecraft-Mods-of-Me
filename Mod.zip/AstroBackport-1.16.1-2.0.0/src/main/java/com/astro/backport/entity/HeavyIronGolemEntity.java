package com.astro.backport.entity;

import com.astro.backport.util.AttrUtil;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.passive.IronGolemEntity;
import net.minecraft.world.World;

/** Rare, much larger and tougher iron golem. Drops a Heavy Core (loot table). */
public class HeavyIronGolemEntity extends IronGolemEntity {
    public static final float SCALE = 1.75F;

    public HeavyIronGolemEntity(EntityType<? extends IronGolemEntity> type, World world) {
        super(type, world);
        AttrUtil.setBase(this, "generic.max_health", 400.0D);
        AttrUtil.setBase(this, "generic.attack_damage", 22.0D);
        AttrUtil.setBase(this, "generic.armor", 8.0D);
        AttrUtil.setBase(this, "generic.knockback_resistance", 1.0D);
        this.setHealth(400.0F);
    }
}
