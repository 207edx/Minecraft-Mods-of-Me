package com.astro.backport.item;

import com.astro.backport.ModEnchants;
import com.astro.backport.ModItems;
import com.astro.backport.util.AstroUtil;
import com.astro.backport.util.AttrUtil;
import com.google.common.collect.Multimap;

import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.enchantment.EnchantmentType;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.MoverType;
import net.minecraft.entity.ai.attributes.Attribute;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.inventory.EquipmentSlotType;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.UseAction;
import net.minecraft.particles.ParticleTypes;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvents;
import net.minecraft.util.math.vector.Vector3d;
import net.minecraft.util.text.TranslationTextComponent;
import net.minecraft.world.World;
import net.minecraft.world.server.ServerWorld;

/** Nether Trident: hold and release for an infernal dash (works in lava and in the Nether). */
public class NetherTridentItem extends Item {
    private Multimap<Attribute, AttributeModifier> modifiers;

    public NetherTridentItem(Item.Properties properties) {
        super(properties);
    }

    @Override
    public Multimap<Attribute, AttributeModifier> getAttributeModifiers(EquipmentSlotType slot) {
        if (slot != EquipmentSlotType.MAINHAND) {
            return super.getAttributeModifiers(slot);
        }
        if (modifiers == null) {
            modifiers = AttrUtil.weapon(8.0D, -2.9D);
        }
        return modifiers;
    }

    @Override
    public boolean hitEntity(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        stack.damageItem(1, attacker, entity -> entity.sendBreakAnimation(EquipmentSlotType.MAINHAND));
        return true;
    }

    @Override
    public int getItemEnchantability() {
        return 18;
    }

    @Override
    public boolean getIsRepairable(ItemStack toRepair, ItemStack repair) {
        return repair.getItem() == ModItems.HEART_OF_NETHER || repair.getItem() == net.minecraft.item.Items.BLAZE_ROD;
    }

    @Override
    public boolean canApplyAtEnchantingTable(ItemStack stack, Enchantment enchantment) {
        return enchantment.type == EnchantmentType.BREAKABLE
            || enchantment.type == ModEnchants.TRIDENT_TYPE
            || enchantment == Enchantments.FIRE_ASPECT
            || enchantment == Enchantments.LOOTING;
    }

    @Override
    public UseAction getUseAction(ItemStack stack) {
        return UseAction.SPEAR;
    }

    @Override
    public int getUseDuration(ItemStack stack) {
        return 72000;
    }

    @Override
    public ActionResult<ItemStack> onItemRightClick(World world, PlayerEntity player, Hand hand) {
        ItemStack stack = player.getHeldItem(hand);
        if (stack.getDamage() >= stack.getMaxDamage() - 1) {
            return ActionResult.resultFail(stack);
        }
        player.setActiveHand(hand);
        return ActionResult.resultConsume(stack);
    }

    @Override
    public void onPlayerStoppedUsing(ItemStack stack, World world, LivingEntity entity, int timeLeft) {
        if (!(entity instanceof PlayerEntity)) {
            return;
        }
        PlayerEntity player = (PlayerEntity) entity;
        if (getUseDuration(stack) - timeLeft < 10) {
            return;
        }
        if (!(player.isInLava() || AstroUtil.inNether(player))) {
            if (!world.isRemote) {
                player.sendStatusMessage(new TranslationTextComponent("message.astrobackport.nether_trident_fizzle"), true);
            }
            return;
        }
        int speedLevel = EnchantmentHelper.getEnchantmentLevel(ModEnchants.SCORCH_VELOCITY, stack);
        float power = 1.6F + 0.6F * speedLevel;
        Hand hand = player.getActiveHand();
        if (!world.isRemote) {
            stack.damageItem(1, player, p -> p.sendBreakAnimation(hand));
            ((ServerWorld) world).spawnParticle(ParticleTypes.FLAME, player.getPosX(), player.getPosY() + 1.0D, player.getPosZ(), 25, 0.4D, 0.5D, 0.4D, 0.08D);
        }
        Vector3d look = player.getLookVec();
        player.addVelocity(look.x * power, look.y * power, look.z * power);
        player.velocityChanged = true;
        if (player.isOnGround()) {
            player.move(MoverType.SELF, new Vector3d(0.0D, 1.2D, 0.0D));
        }
        player.startSpinAttack(20);
        player.getCooldownTracker().setCooldown(this, 30);
        world.playSound(null, player.getPosX(), player.getPosY(), player.getPosZ(),
            SoundEvents.ITEM_TRIDENT_RIPTIDE_3, SoundCategory.PLAYERS, 1.0F, 0.8F);
    }
}
