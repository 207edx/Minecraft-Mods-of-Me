package com.astro.backport.item;

import com.astro.backport.entity.WindChargeEntity;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvents;
import net.minecraft.world.World;

public class WindChargeItem extends Item {
    public WindChargeItem(Item.Properties properties) {
        super(properties);
    }

    @Override
    public ActionResult<ItemStack> onItemRightClick(World world, PlayerEntity player, Hand hand) {
        ItemStack stack = player.getHeldItem(hand);
        world.playSound(null, player.getPosX(), player.getPosY(), player.getPosZ(),
            SoundEvents.ENTITY_SNOWBALL_THROW, SoundCategory.NEUTRAL, 0.6F, 0.5F + world.rand.nextFloat() * 0.2F);
        player.getCooldownTracker().setCooldown(this, 10);
        if (!world.isRemote) {
            WindChargeEntity charge = new WindChargeEntity(world, player);
            charge.shoot(player.getLookVec().x, player.getLookVec().y, player.getLookVec().z, 1.2F, 0.5F);
            world.addEntity(charge);
        }
        if (!player.abilities.isCreativeMode) {
            stack.shrink(1);
        }
        return ActionResult.resultSuccess(stack);
    }
}
