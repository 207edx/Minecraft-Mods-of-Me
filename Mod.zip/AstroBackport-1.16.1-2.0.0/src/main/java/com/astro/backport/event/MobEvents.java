package com.astro.backport.event;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;

import com.astro.backport.AstroBackport;
import com.astro.backport.ModBlocks;
import com.astro.backport.ModEntities;
import com.astro.backport.config.AstroConfig;
import com.astro.backport.entity.BreezeEntity;
import com.astro.backport.entity.HeavyIronGolemEntity;
import com.astro.backport.entity.HoveringInfernoEntity;
import com.astro.backport.entity.PokieSnowmanEntity;
import com.astro.backport.util.AstroUtil;

import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.monster.BlazeEntity;
import net.minecraft.entity.passive.IronGolemEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.particles.ParticleTypes;
import net.minecraft.util.Hand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.server.ServerWorld;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.EntityJoinWorldEvent;
import net.minecraftforge.event.entity.living.LivingDropsEvent;
import net.minecraftforge.event.entity.living.LivingExperienceDropEvent;
import net.minecraftforge.event.entity.living.LivingFallEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.event.world.BlockEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Heavy Iron Golem rolls, Blaze -> Breeze conversion, Pokie Snowman construction/interaction, minion rules. */
@Mod.EventBusSubscriber(modid = AstroBackport.MODID)
public final class MobEvents {
    private static final String ROLLED = "astro_golem_rolled";
    private static final String SNOW_TIME = "astro_snow_ticks";
    private static final List<Object[]> PENDING_GOLEMS = new ArrayList<Object[]>();

    private MobEvents() {}

    // ---- Rare Heavy Iron Golem: roll on join, swap one tick later -------------------------------------

    @SubscribeEvent
    public static void onJoin(EntityJoinWorldEvent event) {
        Entity entity = event.getEntity();
        if (event.getWorld().isRemote || entity.getType() != EntityType.IRON_GOLEM || entity.getPersistentData().getBoolean(ROLLED)) {
            return;
        }
        entity.getPersistentData().putBoolean(ROLLED, true);
        IronGolemEntity golem = (IronGolemEntity) entity;
        if (!golem.isPlayerCreated() && entity.world.rand.nextDouble() < AstroConfig.CFG.heavyGolemChance.get()) {
            synchronized (PENDING_GOLEMS) {
                PENDING_GOLEMS.add(new Object[] {entity.world, entity.getUniqueID()});
            }
        }
    }

    @SubscribeEvent
    public static void onWorldTick(TickEvent.WorldTickEvent event) {
        if (event.phase != TickEvent.Phase.END || event.world.isRemote) {
            return;
        }
        synchronized (PENDING_GOLEMS) {
            Iterator<Object[]> iterator = PENDING_GOLEMS.iterator();
            while (iterator.hasNext()) {
                Object[] pending = iterator.next();
                if (pending[0] != event.world) {
                    continue;
                }
                iterator.remove();
                Entity old = ((ServerWorld) event.world).getEntityByUuid((UUID) pending[1]);
                if (old == null || !old.isAlive()) {
                    continue;
                }
                HeavyIronGolemEntity heavy = ModEntities.HEAVY_IRON_GOLEM.create(event.world);
                if (heavy == null) {
                    continue;
                }
                heavy.setLocationAndAngles(old.getPosX(), old.getPosY(), old.getPosZ(), old.rotationYaw, 0.0F);
                heavy.getPersistentData().putBoolean(ROLLED, true);
                old.remove();
                event.world.addEntity(heavy);
            }
        }
        convertBlazes(event.world);
    }

    // ---- Blaze touching snow in the overworld becomes a Breeze ----------------------------------------

    private static void convertBlazes(World world) {
        if (world.getGameTime() % 10 != 0) {
            return;
        }
        for (Entity entity : ((ServerWorld) world).getEntities(EntityType.BLAZE, e -> true)) {
            BlockPos pos = AstroUtil.blockPos(entity);
            if (!AstroUtil.overworldLike(world, pos) || !touchesSnow(world, pos)) {
                if (entity.getPersistentData().contains(SNOW_TIME)) {
                    entity.getPersistentData().remove(SNOW_TIME);
                }
                continue;
            }
            int ticks = entity.getPersistentData().getInt(SNOW_TIME) + 10;
            entity.getPersistentData().putInt(SNOW_TIME, ticks);
            ((ServerWorld) world).spawnParticle(ParticleTypes.ITEM_SNOWBALL, entity.getPosX(), entity.getPosY() + 1.0D, entity.getPosZ(), 6, 0.3D, 0.5D, 0.3D, 0.02D);
            if (ticks >= 40) {
                BreezeEntity breeze = ModEntities.BREEZE.create(world);
                if (breeze != null) {
                    breeze.setLocationAndAngles(entity.getPosX(), entity.getPosY(), entity.getPosZ(), entity.rotationYaw, entity.rotationPitch);
                    if (entity.hasCustomName()) {
                        breeze.setCustomName(entity.getCustomName());
                    }
                    if (((BlazeEntity) entity).getAttackTarget() != null) {
                        breeze.setAttackTarget(((BlazeEntity) entity).getAttackTarget());
                    }
                    entity.remove();
                    world.addEntity(breeze);
                    world.playSound(null, breeze.getPosX(), breeze.getPosY(), breeze.getPosZ(), SoundEvents.ENTITY_BLAZE_HURT, SoundCategory.HOSTILE, 1.0F, 1.5F);
                    ((ServerWorld) world).spawnParticle(ParticleTypes.CLOUD, breeze.getPosX(), breeze.getPosY() + 1.0D, breeze.getPosZ(), 30, 0.4D, 0.8D, 0.4D, 0.05D);
                }
            }
        }
    }

    private static boolean touchesSnow(World world, BlockPos center) {
        for (int dx = -1; dx <= 1; dx++) {
            for (int dy = -1; dy <= 2; dy++) {
                for (int dz = -1; dz <= 1; dz++) {
                    Block block = world.getBlockState(center.add(dx, dy, dz)).getBlock();
                    if (block == Blocks.SNOW || block == Blocks.SNOW_BLOCK
                        || block == ModBlocks.POWDER_SNOW || block == ModBlocks.TEMPORARY_POWDER_SNOW) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    @SubscribeEvent
    public static void onFall(LivingFallEvent event) {
        if (event.getEntityLiving() instanceof BreezeEntity || event.getEntityLiving() instanceof HoveringInfernoEntity) {
            event.setCanceled(true);
        }
    }

    // ---- Boss minions give nothing ---------------------------------------------------------------------

    @SubscribeEvent
    public static void onDrops(LivingDropsEvent event) {
        if (event.getEntityLiving().getPersistentData().getBoolean(HoveringInfernoEntity.MINION_TAG)) {
            event.setCanceled(true);
        }
    }

    @SubscribeEvent
    public static void onXp(LivingExperienceDropEvent event) {
        if (event.getEntityLiving().getPersistentData().getBoolean(HoveringInfernoEntity.MINION_TAG)) {
            event.setCanceled(true);
        }
    }

    // ---- Pokie Snowman: powder snow (arms), snow block (body base), pumpkin -------------------------------

    @SubscribeEvent
    public static void onPlace(BlockEvent.EntityPlaceEvent event) {
        if (!(event.getWorld() instanceof World) || ((World) event.getWorld()).isRemote) {
            return;
        }
        Block placed = event.getPlacedBlock().getBlock();
        if (placed != Blocks.CARVED_PUMPKIN && placed != Blocks.JACK_O_LANTERN) {
            return;
        }
        World world = (World) event.getWorld();
        BlockPos head = event.getPos();
        BlockPos body = head.down();
        BlockPos base = body.down();
        if (world.getBlockState(body).getBlock() != ModBlocks.POWDER_SNOW || world.getBlockState(base).getBlock() != Blocks.SNOW_BLOCK) {
            return;
        }
        boolean axisX = world.getBlockState(body.east()).getBlock() == ModBlocks.POWDER_SNOW && world.getBlockState(body.west()).getBlock() == ModBlocks.POWDER_SNOW;
        boolean axisZ = world.getBlockState(body.north()).getBlock() == ModBlocks.POWDER_SNOW && world.getBlockState(body.south()).getBlock() == ModBlocks.POWDER_SNOW;
        if (!axisX && !axisZ) {
            return;
        }
        BlockPos[] cells = axisX
            ? new BlockPos[] {head, body, base, body.east(), body.west()}
            : new BlockPos[] {head, body, base, body.north(), body.south()};
        for (BlockPos cell : cells) {
            world.setBlockState(cell, Blocks.AIR.getDefaultState(), 2);
        }
        for (BlockPos cell : cells) {
            world.notifyNeighborsOfStateChange(cell, Blocks.AIR);
        }
        PokieSnowmanEntity pokie = ModEntities.POKIE_SNOWMAN.create(world);
        if (pokie == null) {
            return;
        }
        pokie.setLocationAndAngles(base.getX() + 0.5D, base.getY() + 0.05D, base.getZ() + 0.5D, 0.0F, 0.0F);
        if (event.getEntity() instanceof PlayerEntity) {
            pokie.setOwnerId(event.getEntity().getUniqueID());
        }
        world.addEntity(pokie);
        ((ServerWorld) world).spawnParticle(ParticleTypes.ITEM_SNOWBALL, pokie.getPosX(), pokie.getPosY() + 1.0D, pokie.getPosZ(), 40, 0.5D, 0.8D, 0.5D, 0.05D);
        world.playSound(null, pokie.getPosX(), pokie.getPosY(), pokie.getPosZ(), SoundEvents.BLOCK_SNOW_PLACE, SoundCategory.NEUTRAL, 1.5F, 1.0F);
    }

    /** Right-click: snowball heals, anything else (by the owner) toggles sitting. */
    @SubscribeEvent
    public static void onInteract(PlayerInteractEvent.EntityInteract event) {
        if (!(event.getTarget() instanceof PokieSnowmanEntity) || event.getHand() != Hand.MAIN_HAND) {
            return;
        }
        PokieSnowmanEntity pokie = (PokieSnowmanEntity) event.getTarget();
        PlayerEntity player = event.getPlayer();
        ItemStack held = event.getItemStack();
        if (!player.world.isRemote) {
            if (held.getItem() == Items.SNOWBALL) {
                if (pokie.getHealth() < pokie.getMaxHealth()) {
                    pokie.heal(5.0F);
                    if (!player.abilities.isCreativeMode) {
                        held.shrink(1);
                    }
                    ((ServerWorld) player.world).spawnParticle(ParticleTypes.HEART, pokie.getPosX(), pokie.getPosY() + 1.5D, pokie.getPosZ(), 5, 0.3D, 0.3D, 0.3D, 0.02D);
                }
            } else if (player.getUniqueID().equals(pokie.getOwnerId())) {
                pokie.setPokieSitting(!pokie.isPokieSitting());
                ((ServerWorld) player.world).spawnParticle(ParticleTypes.ITEM_SNOWBALL, pokie.getPosX(), pokie.getPosY() + 1.5D, pokie.getPosZ(), 8, 0.3D, 0.3D, 0.3D, 0.02D);
            } else if (pokie.getOwnerId() == null) {
                pokie.setOwnerId(player.getUniqueID());
            }
        }
        event.setCanceled(true);
        event.setCancellationResult(net.minecraft.util.ActionResultType.SUCCESS);
    }
}
