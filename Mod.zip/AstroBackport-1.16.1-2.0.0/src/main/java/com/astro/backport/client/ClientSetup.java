package com.astro.backport.client;

import java.util.Map;

import com.astro.backport.AstroBackport;
import com.mojang.blaze3d.matrix.MatrixStack;
import com.mojang.blaze3d.vertex.IVertexBuilder;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.IRenderTypeBuffer;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.vector.Matrix4f;
import net.minecraft.util.math.vector.Vector3d;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.event.entity.EntityLeaveWorldEvent;
import net.minecraftforge.event.world.WorldEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Draws a simple brown lead line for custom-leashed entities. Client only. */
@Mod.EventBusSubscriber(modid = AstroBackport.MODID, value = Dist.CLIENT)
public final class ClientSetup {
    private ClientSetup() {}

    /** Called from FMLClientSetupEvent (client only). */
    public static void registerRenderers() {
        net.minecraftforge.fml.client.registry.RenderingRegistry.registerEntityRenderingHandler(com.astro.backport.ModEntities.WIND_CHARGE,
            manager -> new net.minecraft.client.renderer.entity.SpriteRenderer<com.astro.backport.entity.WindChargeEntity>(manager, Minecraft.getInstance().getItemRenderer()));
        net.minecraftforge.fml.client.registry.RenderingRegistry.registerEntityRenderingHandler(com.astro.backport.ModEntities.BREEZE, BreezeRenderer::new);
        net.minecraftforge.fml.client.registry.RenderingRegistry.registerEntityRenderingHandler(com.astro.backport.ModEntities.HEAVY_IRON_GOLEM, HeavyGolemRenderer::new);
        net.minecraftforge.fml.client.registry.RenderingRegistry.registerEntityRenderingHandler(com.astro.backport.ModEntities.HOVERING_INFERNO, HoveringInfernoRenderer::new);
        net.minecraftforge.fml.client.registry.RenderingRegistry.registerEntityRenderingHandler(com.astro.backport.ModEntities.POKIE_SNOWMAN, PokieRenderer::new);
    }

    @SubscribeEvent
    public static void onRenderWorld(RenderWorldLastEvent event) {
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.world == null || ClientLeash.MAP.isEmpty()) {
            return;
        }

        MatrixStack matrixStack = event.getMatrixStack();
        IRenderTypeBuffer.Impl buffer = minecraft.getRenderTypeBuffers().getBufferSource();
        RenderType renderType = RenderType.getLines();
        IVertexBuilder vertices = buffer.getBuffer(renderType);
        Matrix4f matrix = matrixStack.getLast().getMatrix();
        Vector3d camera = minecraft.gameRenderer.getActiveRenderInfo().getProjectedView();
        float partialTicks = event.getPartialTicks();

        for (Map.Entry<Integer, Integer> entry : ClientLeash.MAP.entrySet()) {
            Entity target = minecraft.world.getEntityByID(entry.getKey());
            Entity holder = minecraft.world.getEntityByID(entry.getValue());
            if (target == null || holder == null) {
                continue;
            }

            Vector3d start = interpolate(holder, partialTicks, holder.getHeight() * 0.60D);
            Vector3d end = interpolate(target, partialTicks, target.getHeight() * 0.50D);
            final int segments = 16;
            for (int i = 0; i < segments; i++) {
                Vector3d p1 = ropePoint(start, end, i / (double) segments);
                Vector3d p2 = ropePoint(start, end, (i + 1) / (double) segments);
                vertices.pos(matrix, (float) (p1.x - camera.x), (float) (p1.y - camera.y), (float) (p1.z - camera.z))
                    .color(0.56F, 0.39F, 0.20F, 1.0F).endVertex();
                vertices.pos(matrix, (float) (p2.x - camera.x), (float) (p2.y - camera.y), (float) (p2.z - camera.z))
                    .color(0.56F, 0.39F, 0.20F, 1.0F).endVertex();
            }
        }
        buffer.finish(renderType);
    }

    @SubscribeEvent
    public static void onEntityLeave(EntityLeaveWorldEvent event) {
        // EntityLeaveWorldEvent may also be posted for the integrated server.
        // Only mutate the client render map for entities leaving the active client world.
        if (Minecraft.getInstance().world == event.getWorld()) {
            ClientLeash.removeEntity(event.getEntity().getEntityId());
        }
    }

    @SubscribeEvent
    public static void onWorldUnload(WorldEvent.Unload event) {
        // WorldEvent#getWorld() is typed as IWorld in this Forge version, which
        // does not expose World#isRemote. Identity-check the active client world instead.
        if (Minecraft.getInstance().world == event.getWorld()) {
            ClientLeash.clear();
        }
    }

    private static Vector3d interpolate(Entity entity, float partialTicks, double yOffset) {
        return new Vector3d(
            MathHelper.lerp(partialTicks, entity.lastTickPosX, entity.getPosX()),
            MathHelper.lerp(partialTicks, entity.lastTickPosY, entity.getPosY()) + yOffset,
            MathHelper.lerp(partialTicks, entity.lastTickPosZ, entity.getPosZ())
        );
    }

    private static Vector3d ropePoint(Vector3d start, Vector3d end, double t) {
        double sag = Math.sin(t * Math.PI) * 0.25D * Math.min(1.0D, start.distanceTo(end) / 6.0D);
        return new Vector3d(
            start.x + (end.x - start.x) * t,
            start.y + (end.y - start.y) * t - sag,
            start.z + (end.z - start.z) * t
        );
    }
}
