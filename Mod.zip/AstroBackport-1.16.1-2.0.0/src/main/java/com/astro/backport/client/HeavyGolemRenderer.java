package com.astro.backport.client;

import com.astro.backport.AstroBackport;
import com.astro.backport.entity.HeavyIronGolemEntity;
import com.mojang.blaze3d.matrix.MatrixStack;

import net.minecraft.client.renderer.entity.EntityRendererManager;
import net.minecraft.client.renderer.entity.IronGolemRenderer;
import net.minecraft.entity.passive.IronGolemEntity;
import net.minecraft.util.ResourceLocation;

public class HeavyGolemRenderer extends IronGolemRenderer {
    private static final ResourceLocation TEXTURE = new ResourceLocation(AstroBackport.MODID, "textures/entity/heavy_iron_golem.png");

    public HeavyGolemRenderer(EntityRendererManager manager) {
        super(manager);
        this.shadowSize = 1.8F;
    }

    @Override
    public ResourceLocation getEntityTexture(IronGolemEntity entity) {
        return TEXTURE;
    }

    @Override
    protected void preRenderCallback(IronGolemEntity entity, MatrixStack matrixStack, float partialTickTime) {
        super.preRenderCallback(entity, matrixStack, partialTickTime);
        matrixStack.scale(HeavyIronGolemEntity.SCALE, HeavyIronGolemEntity.SCALE, HeavyIronGolemEntity.SCALE);
    }
}
