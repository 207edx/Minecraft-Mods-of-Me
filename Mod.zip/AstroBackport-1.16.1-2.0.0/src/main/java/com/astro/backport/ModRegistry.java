package com.astro.backport;

import net.minecraft.block.Block;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.entity.EntityType;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = AstroBackport.MODID, bus = Mod.EventBusSubscriber.Bus.MOD)
public final class ModRegistry {
    private ModRegistry() {}

    @SubscribeEvent
    public static void blocks(RegistryEvent.Register<Block> event) {
        event.getRegistry().registerAll(ModItems.blocks());
    }

    @SubscribeEvent
    public static void items(RegistryEvent.Register<Item> event) {
        event.getRegistry().registerAll(ModItems.all());
        event.getRegistry().register(new BlockItem(ModBlocks.TEMPORARY_POWDER_SNOW, new Item.Properties())
            .setRegistryName(AstroBackport.MODID, "temporary_powder_snow"));
    }

    @SubscribeEvent
    public static void entities(RegistryEvent.Register<EntityType<?>> event) {
        event.getRegistry().registerAll(ModEntities.all());
    }

    @SubscribeEvent
    public static void enchantments(RegistryEvent.Register<Enchantment> event) {
        event.getRegistry().registerAll(ModEnchants.DENSITY, ModEnchants.BREACH, ModEnchants.WIND_BURST, ModEnchants.LUNGE,
            ModEnchants.INFERNAL_WARD, ModEnchants.LAVA_SIGHT, ModEnchants.SCORCH_VELOCITY, ModEnchants.SEARING_EDGE);
    }
}
