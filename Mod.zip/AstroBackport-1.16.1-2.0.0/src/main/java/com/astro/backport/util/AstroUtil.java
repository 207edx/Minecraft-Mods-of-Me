package com.astro.backport.util;

import com.astro.backport.ModEntities;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.vector.Vector3d;
import net.minecraft.world.World;
import net.minecraft.world.biome.Biome;

public final class AstroUtil {
    public static final String BARRIER_KEY = "astro_barrier_until";

    private AstroUtil() {}

    public static BlockPos blockPos(Entity entity) {
        return new BlockPos(entity.getPosX(), entity.getPosY(), entity.getPosZ());
    }

    public static boolean inNether(Entity entity) {
        return entity.world.getBiome(blockPos(entity)).getCategory() == Biome.Category.NETHER;
    }

    public static boolean overworldLike(World world, BlockPos pos) {
        Biome.Category category = world.getBiome(pos).getCategory();
        return category != Biome.Category.NETHER && category != Biome.Category.THEEND && category != Biome.Category.OCEAN;
    }

    public static Vector3d center(Entity entity) {
        return new Vector3d(entity.getPosX(), entity.getPosY() + entity.getHeight() * 0.5D, entity.getPosZ());
    }

    public static boolean freezeImmune(Entity entity) {
        EntityType<?> type = entity.getType();
        if (type == EntityType.SNOW_GOLEM || type == EntityType.STRAY || type == EntityType.POLAR_BEAR
            || type == ModEntities.POKIE_SNOWMAN) {
            return true;
        }
        return entity.getPersistentData().getLong(BARRIER_KEY) > entity.world.getGameTime();
    }
}
