package com.astro.backport.event;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

import com.astro.backport.AstroBackport;
import com.astro.backport.net.Network;

import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.item.BoatEntity;
import net.minecraft.entity.item.minecart.AbstractMinecartEntity;
import net.minecraft.entity.monster.IMob;
import net.minecraft.entity.merchant.villager.AbstractVillagerEntity;
import net.minecraft.entity.passive.WaterMobEntity;
import com.astro.backport.config.AstroConfig;
import net.minecraft.entity.MobEntity;
import java.util.List;
import net.minecraftforge.fml.event.server.FMLServerStoppedEvent;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.ActionResultType;
import net.minecraft.util.Hand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvents;
import net.minecraft.util.math.vector.Vector3d;
import net.minecraft.world.World;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.EntityJoinWorldEvent;
import net.minecraftforge.event.entity.EntityLeaveWorldEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.network.PacketDistributor;

/**
 * Adds lead support to boats, minecarts and non-boss hostile mobs.
 * Vanilla remains responsible for ordinary passive-animal leashing.
 */
@Mod.EventBusSubscriber(modid = AstroBackport.MODID)
public final class LeashEvents {
    public static final String DATA_KEY = "astrobackport_leash_holder";
    private static final double PULL_START_DISTANCE = 4.0D;
        private static final Map<UUID, Entity> LEASHED = new HashMap<UUID, Entity>();

    private LeashEvents() {}

    @SubscribeEvent
    public static void onServerStopped(FMLServerStoppedEvent event) {
        LEASHED.clear();
    }

    /** Vanilla leashed animals also get glide-towing and jump-following from the holder. */
    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        PlayerEntity player = event.player;
        if (event.phase != TickEvent.Phase.END || player.world.isRemote) {
            return;
        }
        if (!player.isElytraFlying() && (player.isOnGround() || player.getMotion().y <= 0.05D)) {
            return;
        }
        List<MobEntity> mobs = player.world.getEntitiesWithinAABB(MobEntity.class, player.getBoundingBox().grow(14.0D),
            mob -> mob.getLeashHolder() == player);
        for (MobEntity mob : mobs) {
            LeashPhysics.pull(player, mob);
        }
    }

    private static boolean isSupportedTarget(Entity entity) {
        if (entity instanceof BoatEntity || entity instanceof AbstractMinecartEntity) {
            return true;
        }
        // Vanilla already leashes ordinary animals; these are the extras vanilla refuses.
        return entity instanceof LivingEntity && entity.isNonBoss() && !(entity instanceof PlayerEntity)
            && (entity instanceof IMob || entity instanceof AbstractVillagerEntity || entity instanceof WaterMobEntity);
    }

    @SubscribeEvent
    public static void onEntityInteract(PlayerInteractEvent.EntityInteract event) {
        if (event.getHand() != Hand.MAIN_HAND) {
            return;
        }

        Entity target = event.getTarget();
        if (!isSupportedTarget(target)) {
            return;
        }

        PlayerEntity player = event.getPlayer();
        World world = event.getWorld();
        boolean alreadyLeashed = target.getPersistentData().contains(DATA_KEY);

        // Sneak + right-click an attached target to detach it and return the lead.
        if (alreadyLeashed) {
            if (player.isSneaking()) {
                if (!world.isRemote) {
                    LEASHED.remove(target.getUniqueID());
                    release(target, true);
                }
                event.setCanceled(true);
                event.setCancellationResult(ActionResultType.SUCCESS);
            }
            return;
        }

        ItemStack held = event.getItemStack();
        if (held.getItem() != Items.LEAD) {
            return;
        }

        if (!world.isRemote) {
            target.getPersistentData().putString(DATA_KEY, player.getUniqueID().toString());
            LEASHED.put(target.getUniqueID(), target);
            syncToTrackers(target, player.getEntityId());
            world.playSound(null, target.getPosX(), target.getPosY(), target.getPosZ(),
                SoundEvents.ENTITY_LEASH_KNOT_PLACE, SoundCategory.NEUTRAL, 1.0F, 1.0F);
            if (!player.abilities.isCreativeMode) {
                held.shrink(1);
            }
        }

        event.setCanceled(true);
        event.setCancellationResult(ActionResultType.SUCCESS);
    }

    private static void release(Entity target, boolean dropLead) {
        target.getPersistentData().remove(DATA_KEY);
        Network.CHANNEL.send(PacketDistributor.TRACKING_ENTITY.with(() -> target),
            new Network.LeashSync(target.getEntityId(), -1));
        if (dropLead && target.world.isBlockLoaded(new net.minecraft.util.math.BlockPos(target.getPosX(), target.getPosY(), target.getPosZ()))) {
            target.entityDropItem(Items.LEAD);
        }
    }

    private static void syncToTrackers(Entity target, int holderId) {
        Network.CHANNEL.send(PacketDistributor.TRACKING_ENTITY.with(() -> target),
            new Network.LeashSync(target.getEntityId(), holderId));
    }

    @SubscribeEvent
    public static void onEntityJoin(EntityJoinWorldEvent event) {
        Entity entity = event.getEntity();
        if (!event.getWorld().isRemote && entity.getPersistentData().contains(DATA_KEY)) {
            LEASHED.put(entity.getUniqueID(), entity);
        }
    }

    @SubscribeEvent
    public static void onEntityLeave(EntityLeaveWorldEvent event) {
        if (event.getWorld().isRemote) {
            return;
        }
        Entity entity = event.getEntity();
        LEASHED.remove(entity.getUniqueID());

        // A dead/destroyed custom target returns its lead. LivingDeathEvent clears the key first,
        // preventing duplicate drops for living targets.
        if (!entity.isAlive() && entity.getPersistentData().contains(DATA_KEY)) {
            release(entity, true);
        }
    }

    @SubscribeEvent
    public static void onStartTracking(PlayerEvent.StartTracking event) {
        Entity target = event.getTarget();
        if (!target.getPersistentData().contains(DATA_KEY) || !(event.getPlayer() instanceof ServerPlayerEntity)) {
            return;
        }

        UUID holderId;
        try {
            holderId = UUID.fromString(target.getPersistentData().getString(DATA_KEY));
        } catch (IllegalArgumentException exception) {
            return;
        }

        PlayerEntity holder = target.world.getPlayerByUuid(holderId);
        if (holder != null) {
            Network.CHANNEL.send(PacketDistributor.PLAYER.with(() -> (ServerPlayerEntity) event.getPlayer()),
                new Network.LeashSync(target.getEntityId(), holder.getEntityId()));
        }
    }

    @SubscribeEvent
    public static void onLivingDeath(LivingDeathEvent event) {
        Entity entity = event.getEntityLiving();
        if (!entity.world.isRemote && entity.getPersistentData().contains(DATA_KEY)) {
            LEASHED.remove(entity.getUniqueID());
            release(entity, true);
        }
    }

    @SubscribeEvent
    public static void onWorldTick(TickEvent.WorldTickEvent event) {
        if (event.phase != TickEvent.Phase.END || event.world.isRemote) {
            return;
        }

        Iterator<Map.Entry<UUID, Entity>> iterator = LEASHED.entrySet().iterator();
        while (iterator.hasNext()) {
            Entity target = iterator.next().getValue();
            if (target.world != event.world) {
                continue;
            }
            if (!target.isAlive()) {
                iterator.remove();
                continue;
            }

            UUID holderId;
            try {
                holderId = UUID.fromString(target.getPersistentData().getString(DATA_KEY));
            } catch (IllegalArgumentException exception) {
                iterator.remove();
                target.getPersistentData().remove(DATA_KEY);
                continue;
            }

            PlayerEntity holder = event.world.getPlayerByUuid(holderId);
            if (holder == null) {
                // Keep the leash while its owner is offline or in another dimension.
                continue;
            }

            double distance = holder.getDistance(target);
            double breakDistance = holder.isElytraFlying() ? 48.0D : AstroConfig.CFG.leashBreakDistance.get();
            if (!holder.isAlive() || distance > breakDistance) {
                iterator.remove();
                release(target, true);
                continue;
            }
            LeashPhysics.pull(holder, target);
        }
    }
}
