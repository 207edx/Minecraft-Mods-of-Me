package com.astro.backport.entity;

import java.util.List;

import com.astro.backport.ModEntities;
import com.astro.backport.util.AttrUtil;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.MobEntity;
import net.minecraft.entity.FlyingEntity;
import net.minecraft.entity.ai.goal.HurtByTargetGoal;
import net.minecraft.entity.ai.goal.NearestAttackableTargetGoal;
import net.minecraft.entity.monster.BlazeEntity;
import net.minecraft.entity.monster.IMob;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.entity.projectile.FireballEntity;
import net.minecraft.entity.projectile.SmallFireballEntity;
import net.minecraft.nbt.CompoundNBT;
import net.minecraft.network.datasync.DataParameter;
import net.minecraft.network.datasync.DataSerializers;
import net.minecraft.network.datasync.EntityDataManager;
import net.minecraft.particles.ParticleTypes;
import net.minecraft.util.DamageSource;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.SoundEvents;
import net.minecraft.util.math.vector.Vector3d;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.world.BossInfo;
import net.minecraft.world.World;
import net.minecraft.world.server.ServerBossInfo;
import net.minecraft.world.server.ServerWorld;

/**
 * Hovering Inferno - the Nether boss. Hovers, throws large fireballs, raises a damage shield,
 * summons weakened Blazes/Breezes, and burns anything that touches it. Drops the Heart of Nether.
 */
public class HoveringInfernoEntity extends FlyingEntity implements IMob {
    private static final DataParameter<Boolean> SHIELDED = EntityDataManager.createKey(HoveringInfernoEntity.class, DataSerializers.BOOLEAN);
    public static final String MINION_TAG = "astro_minion";
    private final ServerBossInfo bossInfo = new ServerBossInfo(getDisplayName(), BossInfo.Color.RED, BossInfo.Overlay.PROGRESS);
    private int shieldTicks;
    private int shieldCooldown = 300;
    private int fireballCooldown = 60;
    private int summonCooldown = 200;
    private int novaCooldown = 240;
    private int volley;

    public HoveringInfernoEntity(EntityType<? extends HoveringInfernoEntity> type, World world) {
        super(type, world);
        this.experienceValue = 500;
        this.setNoGravity(true);
        AttrUtil.setBase(this, "generic.max_health", 500.0D);
        AttrUtil.setBase(this, "generic.armor", 8.0D);
        AttrUtil.setBase(this, "generic.knockback_resistance", 1.0D);
        AttrUtil.setBase(this, "generic.follow_range", 64.0D);
        AttrUtil.setBase(this, "generic.attack_damage", 10.0D);
        this.setHealth(500.0F);
        this.enablePersistence();
    }

    @Override
    protected void registerData() {
        super.registerData();
        dataManager.register(SHIELDED, Boolean.FALSE);
    }

    @Override
    protected void registerGoals() {
        targetSelector.addGoal(1, new HurtByTargetGoal(this));
        targetSelector.addGoal(2, new NearestAttackableTargetGoal<PlayerEntity>(this, PlayerEntity.class, false));
    }

    public boolean isShielded() {
        return dataManager.get(SHIELDED);
    }

    private int phase() {
        float fraction = getHealth() / getMaxHealth();
        return fraction > 0.66F ? 1 : (fraction > 0.33F ? 2 : 3);
    }

    @Override
    public boolean isNonBoss() {
        return false;
    }

    @Override
    public boolean canDespawn(double distance) {
        return false;
    }

    @Override
    protected int getExperiencePoints(PlayerEntity player) {
        return 500;
    }

    @Override
    public boolean attackEntityFrom(DamageSource source, float amount) {
        if (source.isFireDamage()) {
            return false;
        }
        if (isShielded() && !source.canHarmInCreative()) {
            playSound(SoundEvents.ITEM_SHIELD_BLOCK, 1.0F, 0.7F);
            return false;
        }
        return super.attackEntityFrom(source, amount);
    }

    @Override
    protected void updateAITasks() {
        super.updateAITasks();
        bossInfo.setPercent(getHealth() / getMaxHealth());
        LivingEntity target = getAttackTarget();
        hover(target);
        if (ticksExisted % 4 == 0) {
            ((ServerWorld) world).spawnParticle(ParticleTypes.FLAME, getPosX(), getPosY() + 1.4D, getPosZ(), 6, 1.0D, 1.0D, 1.0D, 0.02D);
        }
        if (ticksExisted % 10 == 0) {
            burnNearby();
        }
        if (shieldTicks > 0) {
            if (--shieldTicks == 0) {
                dataManager.set(SHIELDED, Boolean.FALSE);
                shieldCooldown = 400;
            }
        } else if (phase() >= 2 && --shieldCooldown <= 0) {
            shieldTicks = 100;
            dataManager.set(SHIELDED, Boolean.TRUE);
            playSound(SoundEvents.ENTITY_WITHER_SPAWN, 1.0F, 1.6F);
        }
        if (target == null) {
            return;
        }
        faceEntity(target, 30.0F, 30.0F);
        if (--fireballCooldown <= 0) {
            fireballCooldown = phase() == 3 ? 40 : 65;
            shootFireballs(target);
        }
        if (phase() >= 2 && --summonCooldown <= 0) {
            summonCooldown = 260;
            summonMinions(target);
        }
        if (phase() == 3 && --novaCooldown <= 0) {
            novaCooldown = 220;
            nova();
        }
    }

    private void hover(LivingEntity target) {
        Vector3d desired;
        if (target != null) {
            double angle = ticksExisted * 0.02D;
            desired = new Vector3d(target.getPosX() + Math.cos(angle) * 9.0D, target.getPosY() + 6.5D, target.getPosZ() + Math.sin(angle) * 9.0D);
        } else {
            desired = getPositionVec();
        }
        Vector3d delta = desired.subtract(getPositionVec());
        double length = delta.length();
        if (length > 0.5D) {
            Vector3d push = delta.scale(1.0D / length).scale(0.05D * Math.min(1.0D, length / 4.0D));
            setMotion(getMotion().add(push));
        } else {
            setMotion(getMotion().scale(0.8D));
        }
    }

    private void shootFireballs(LivingEntity target) {
        int shots = phase() == 3 ? 3 : 1;
        playSound(SoundEvents.ENTITY_GHAST_WARN, 3.0F, 0.7F);
        for (int i = 0; i < shots; i++) {
            double spread = (i - (shots - 1) / 2.0D) * 0.35D;
            Vector3d aim = new Vector3d(target.getPosX() - getPosX() + spread * 4.0D, target.getPosYEye() - (getPosY() + 1.5D), target.getPosZ() - getPosZ() - spread * 4.0D);
            FireballEntity fireball = new FireballEntity(world, this, aim.x, aim.y, aim.z);
            fireball.explosionPower = 3;
            fireball.setPosition(getPosX(), getPosY() + 1.5D, getPosZ());
            world.addEntity(fireball);
        }
        volley++;
        if (volley % 3 == 0) {
            for (int i = 0; i < 4; i++) {
                SmallFireballEntity small = new SmallFireballEntity(world, this, target.getPosX() - getPosX() + rand.nextGaussian() * 2.0D,
                    target.getPosYEye() - (getPosY() + 1.5D), target.getPosZ() - getPosZ() + rand.nextGaussian() * 2.0D);
                small.setPosition(getPosX(), getPosY() + 1.5D, getPosZ());
                world.addEntity(small);
            }
        }
        playSound(SoundEvents.ENTITY_GHAST_SHOOT, 3.0F, 0.6F);
    }

    private void summonMinions(LivingEntity target) {
        List<MobEntity> existing = world.getEntitiesWithinAABB(MobEntity.class, getBoundingBox().grow(40.0D),
            entity -> entity.getPersistentData().getBoolean(MINION_TAG));
        if (existing.size() >= 6) {
            return;
        }
        for (int i = 0; i < 2; i++) {
            MobEntity minion = rand.nextBoolean() ? EntityType.BLAZE.create(world) : ModEntities.BREEZE.create(world);
            if (minion == null) {
                continue;
            }
            minion.setLocationAndAngles(getPosX() + rand.nextGaussian() * 3.0D, getPosY() - 1.0D, getPosZ() + rand.nextGaussian() * 3.0D, rand.nextFloat() * 360.0F, 0.0F);
            AttrUtil.setBase(minion, "generic.max_health", 8.0D);
            AttrUtil.setBase(minion, "generic.attack_damage", 2.0D);
            minion.setHealth(8.0F);
            minion.getPersistentData().putBoolean(MINION_TAG, true);
            minion.enablePersistence();
            minion.setAttackTarget(target);
            world.addEntity(minion);
        }
        playSound(SoundEvents.ENTITY_BLAZE_AMBIENT, 3.0F, 0.5F);
    }

    private void nova() {
        playSound(SoundEvents.ENTITY_GENERIC_EXPLODE, 3.0F, 0.6F);
        ((ServerWorld) world).spawnParticle(ParticleTypes.FLAME, getPosX(), getPosY() + 1.0D, getPosZ(), 200, 5.0D, 0.5D, 5.0D, 0.15D);
        for (PlayerEntity player : world.getEntitiesWithinAABB(PlayerEntity.class, getBoundingBox().grow(11.0D))) {
            player.attackEntityFrom(DamageSource.causeMobDamage(this), 8.0F);
            Vector3d away = player.getPositionVec().subtract(getPositionVec()).normalize();
            player.addVelocity(away.x * 1.4D, 0.5D, away.z * 1.4D);
            player.velocityChanged = true;
        }
    }

    private void burnNearby() {
        for (LivingEntity entity : world.getEntitiesWithinAABB(LivingEntity.class, getBoundingBox().grow(1.6D))) {
            if (entity == this || entity instanceof HoveringInfernoEntity || entity.getPersistentData().getBoolean(MINION_TAG)
                || entity instanceof BlazeEntity) {
                continue;
            }
            entity.attackEntityFrom(DamageSource.causeMobDamage(this), 6.0F);
            entity.setFire(8);
        }
    }

    @Override
    public void readAdditional(CompoundNBT compound) {
        super.readAdditional(compound);
        if (hasCustomName()) {
            bossInfo.setName(getDisplayName());
        }
    }

    @Override
    public void setCustomName(ITextComponent name) {
        super.setCustomName(name);
        bossInfo.setName(getDisplayName());
    }

    @Override
    public void addTrackingPlayer(ServerPlayerEntity player) {
        super.addTrackingPlayer(player);
        bossInfo.addPlayer(player);
    }

    @Override
    public void removeTrackingPlayer(ServerPlayerEntity player) {
        super.removeTrackingPlayer(player);
        bossInfo.removePlayer(player);
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return SoundEvents.ENTITY_BLAZE_AMBIENT;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.ENTITY_BLAZE_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.ENTITY_WITHER_DEATH;
    }

    @Override
    protected float getSoundPitch() {
        return 0.6F;
    }

    @Override
    protected float getSoundVolume() {
        return 2.0F;
    }
}
