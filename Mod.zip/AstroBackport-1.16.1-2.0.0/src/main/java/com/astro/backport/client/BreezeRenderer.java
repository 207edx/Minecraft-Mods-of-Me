package com.astro.backport.client;

import com.astro.backport.AstroBackport;
import com.astro.backport.entity.BreezeEntity;

import net.minecraft.client.renderer.entity.EntityRendererManager;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.model.BlazeModel;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.BlockPos;

public class BreezeRenderer extends MobRenderer<BreezeEntity, BlazeModel<BreezeEntity>> {
    private static final ResourceLocation TEXTURE = new ResourceLocation(AstroBackport.MODID, "textures/entity/breeze.png");

    public BreezeRenderer(EntityRendererManager manager) {
        super(manager, new BlazeModel<BreezeEntity>(), 0.5F);
    }

    @Override
    protected int getBlockLight(BreezeEntity entity, BlockPos pos) {
        return 15;
    }

    @Override
    public ResourceLocation getEntityTexture(BreezeEntity entity) {
        return TEXTURE;
    }
}
