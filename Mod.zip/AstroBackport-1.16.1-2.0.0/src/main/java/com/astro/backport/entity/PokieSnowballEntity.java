package com.astro.backport.entity;

import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.projectile.SnowballEntity;
import net.minecraft.potion.EffectInstance;
import net.minecraft.potion.Effects;
import net.minecraft.util.DamageSource;
import net.minecraft.util.math.EntityRayTraceResult;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.world.World;

/** Snowball that deals real damage and chills the target. Reuses the vanilla snowball entity type. */
public class PokieSnowballEntity extends SnowballEntity {
    private final LivingEntity owner;

    public PokieSnowballEntity(World world, LivingEntity owner) {
        super(world, owner);
        this.owner = owner;
    }

    @Override
    protected void onImpact(RayTraceResult result) {
        if (!world.isRemote && result.getType() == RayTraceResult.Type.ENTITY) {
            Entity hit = ((EntityRayTraceResult) result).getEntity();
            if (hit instanceof LivingEntity && hit != owner) {
                hit.attackEntityFrom(DamageSource.causeThrownDamage(this, owner), 3.0F);
                ((LivingEntity) hit).addPotionEffect(new EffectInstance(Effects.SLOWNESS, 60, 1));
            }
        }
        super.onImpact(result);
    }
}
