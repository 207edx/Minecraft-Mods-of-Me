package com.astro.backport.client;

import com.astro.backport.AstroBackport;
import com.astro.backport.ModBlocks;
import com.astro.backport.ModEnchants;
import com.astro.backport.item.NetherTridentItem;
import com.astro.backport.item.SpearItem;
import com.astro.backport.net.Network;

import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.player.ClientPlayerEntity;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.Hand;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.vector.Vector3d;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityViewRenderEvent;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Client-only: spear jab reach, lava sight, powder snow fog. */
@Mod.EventBusSubscriber(modid = AstroBackport.MODID, value = Dist.CLIENT)
public final class ClientEvents {
    private ClientEvents() {}

    @SubscribeEvent
    public static void onClick(InputEvent.ClickInputEvent event) {
        Minecraft mc = Minecraft.getInstance();
        ClientPlayerEntity player = mc.player;
        if (!event.isAttack() || player == null || mc.world == null || mc.currentScreen != null
            || !(player.getHeldItemMainhand().getItem() instanceof SpearItem)) {
            return;
        }
        Vector3d start = player.getEyePosition(1.0F);
        Vector3d end = start.add(player.getLookVec().scale(SpearItem.JAB_REACH));
        Entity best = null;
        double bestDistance = Double.MAX_VALUE;
        for (Entity entity : mc.world.getEntitiesWithinAABBExcludingEntity(player, player.getBoundingBox().expand(player.getLookVec().scale(SpearItem.JAB_REACH)).grow(1.0D))) {
            if (!(entity instanceof LivingEntity) || !entity.canBeCollidedWith()) {
                continue;
            }
            AxisAlignedBB box = entity.getBoundingBox().grow(entity.getCollisionBorderSize());
            java.util.Optional<Vector3d> hit = box.rayTrace(start, end);
            if (hit.isPresent()) {
                double d = start.distanceTo(hit.get());
                if (d < bestDistance) {
                    bestDistance = d;
                    best = entity;
                }
            }
        }
        if (best == null || player.getDistance(best) <= 3.0F) {
            return; // nothing, or within vanilla reach: let vanilla attack
        }
        RayTraceResult block = mc.objectMouseOver;
        if (block != null && block.getType() == RayTraceResult.Type.BLOCK && block.getHitVec().distanceTo(start) < bestDistance - 0.3D) {
            return;
        }
        Network.CHANNEL.sendToServer(new Network.SpearJab(best.getEntityId()));
        player.swingArm(Hand.MAIN_HAND);
        event.setCanceled(true);
    }

    private static boolean hasLavaSight(ClientPlayerEntity player) {
        for (Hand hand : Hand.values()) {
            ItemStack stack = player.getHeldItem(hand);
            if (stack.getItem() instanceof NetherTridentItem && EnchantmentHelper.getEnchantmentLevel(ModEnchants.LAVA_SIGHT, stack) > 0) {
                return true;
            }
        }
        return false;
    }

    private static boolean eyesInPowderSnow(ClientPlayerEntity player) {
        BlockPos eye = new BlockPos(player.getPosX(), player.getPosYEye(), player.getPosZ());
        net.minecraft.block.Block block = player.world.getBlockState(eye).getBlock();
        return block == ModBlocks.POWDER_SNOW || block == ModBlocks.TEMPORARY_POWDER_SNOW;
    }

    @SubscribeEvent
    public static void onFogDensity(EntityViewRenderEvent.FogDensity event) {
        ClientPlayerEntity player = Minecraft.getInstance().player;
        if (player == null) {
            return;
        }
        if (player.areEyesInFluid(FluidTags.LAVA) && hasLavaSight(player)) {
            event.setDensity(0.03F);
            event.setCanceled(true);
        } else if (eyesInPowderSnow(player)) {
            event.setDensity(1.2F);
            event.setCanceled(true);
        }
    }

    @SubscribeEvent
    public static void onFogColor(EntityViewRenderEvent.FogColors event) {
        ClientPlayerEntity player = Minecraft.getInstance().player;
        if (player != null && eyesInPowderSnow(player)) {
            event.setRed(0.92F);
            event.setGreen(0.96F);
            event.setBlue(1.0F);
        }
    }
}
