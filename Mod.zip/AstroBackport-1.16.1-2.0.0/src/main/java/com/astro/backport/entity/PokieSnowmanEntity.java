package com.astro.backport.entity;

import java.util.EnumSet;
import java.util.Optional;
import java.util.UUID;

import com.astro.backport.ModBlocks;
import com.astro.backport.util.AstroUtil;
import com.astro.backport.util.AttrUtil;

import net.minecraft.block.BlockState;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.entity.ai.goal.LookAtGoal;
import net.minecraft.entity.ai.goal.LookRandomlyGoal;
import net.minecraft.entity.ai.goal.NearestAttackableTargetGoal;
import net.minecraft.entity.ai.goal.RangedAttackGoal;
import net.minecraft.entity.ai.goal.WaterAvoidingRandomWalkingGoal;
import net.minecraft.entity.monster.IMob;
import net.minecraft.entity.monster.MonsterEntity;
import net.minecraft.entity.MobEntity;
import net.minecraft.entity.passive.GolemEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.monster.IRangedAttackMob;
import net.minecraft.nbt.CompoundNBT;
import net.minecraft.network.datasync.DataParameter;
import net.minecraft.network.datasync.DataSerializers;
import net.minecraft.network.datasync.EntityDataManager;
import net.minecraft.particles.ParticleTypes;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.World;
import net.minecraft.world.server.ServerWorld;

/** Pokie Snowman: loyal snow golem pet with 40 HP. Sits on command and casts a 3x3x3 powder snow barrier around its owner. */
public class PokieSnowmanEntity extends GolemEntity implements IRangedAttackMob {
    private static final DataParameter<Optional<UUID>> OWNER = EntityDataManager.createKey(PokieSnowmanEntity.class, DataSerializers.OPTIONAL_UNIQUE_ID);
    private static final DataParameter<Boolean> SITTING = EntityDataManager.createKey(PokieSnowmanEntity.class, DataSerializers.BOOLEAN);
    private int barrierCooldown;

    public PokieSnowmanEntity(EntityType<? extends PokieSnowmanEntity> type, World world) {
        super(type, world);
        AttrUtil.setBase(this, "generic.max_health", 40.0D);
        AttrUtil.setBase(this, "generic.movement_speed", 0.26D);
        this.setHealth(40.0F);
        this.enablePersistence();
    }

    @Override
    protected void registerData() {
        super.registerData();
        dataManager.register(OWNER, Optional.empty());
        dataManager.register(SITTING, Boolean.FALSE);
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(1, new SitGoal(this));
        goalSelector.addGoal(2, new RangedAttackGoal(this, 1.25D, 20, 10.0F));
        goalSelector.addGoal(3, new FollowOwnerGoal(this, 1.1D, 4.0F, 14.0F));
        goalSelector.addGoal(4, new WaterAvoidingRandomWalkingGoal(this, 1.0D, 1.0000001E-5F));
        goalSelector.addGoal(5, new LookAtGoal(this, PlayerEntity.class, 6.0F));
        goalSelector.addGoal(6, new LookRandomlyGoal(this));
        targetSelector.addGoal(1, new NearestAttackableTargetGoal<MobEntity>(this, MobEntity.class, 10, true, false, entity -> entity instanceof IMob));
    }

    @Override
    public boolean canDespawn(double distanceToClosestPlayer) {
        return false;
    }

    public UUID getOwnerId() {
        return dataManager.get(OWNER).orElse(null);
    }

    public void setOwnerId(UUID id) {
        dataManager.set(OWNER, Optional.ofNullable(id));
    }

    public PlayerEntity getOwner() {
        UUID id = getOwnerId();
        return id == null ? null : world.getPlayerByUuid(id);
    }

    public boolean isPokieSitting() {
        return dataManager.get(SITTING);
    }

    public void setPokieSitting(boolean sitting) {
        dataManager.set(SITTING, sitting);
    }

    @Override
    public void writeAdditional(CompoundNBT compound) {
        super.writeAdditional(compound);
        if (getOwnerId() != null) {
            compound.putUniqueId("PokieOwner", getOwnerId());
        }
        compound.putBoolean("PokieSitting", isPokieSitting());
    }

    @Override
    public void readAdditional(CompoundNBT compound) {
        super.readAdditional(compound);
        if (compound.hasUniqueId("PokieOwner")) {
            setOwnerId(compound.getUniqueId("PokieOwner"));
        }
        setPokieSitting(compound.getBoolean("PokieSitting"));
    }

    @Override
    public void attackEntityWithRangedAttack(LivingEntity target, float distanceFactor) {
        PokieSnowballEntity snowball = new PokieSnowballEntity(world, this);
        double d0 = target.getPosYEye() - 1.1D;
        double d1 = target.getPosX() - getPosX();
        double d2 = d0 - snowball.getPosY();
        double d3 = target.getPosZ() - getPosZ();
        float f = MathHelper.sqrt(d1 * d1 + d3 * d3) * 0.2F;
        snowball.shoot(d1, d2 + (double) f, d3, 1.6F, 12.0F);
        playSound(SoundEvents.ENTITY_SNOW_GOLEM_SHOOT, 1.0F, 0.4F / (getRNG().nextFloat() * 0.4F + 0.8F));
        world.addEntity(snowball);
    }

    @Override
    protected void updateAITasks() {
        super.updateAITasks();
        if (world.isRemote) {
            return;
        }
        if (barrierCooldown > 0) {
            barrierCooldown--;
        }
        PlayerEntity owner = getOwner();
        if (owner == null || getDistance(owner) > 24.0F) {
            return;
        }
        // Defend the owner: target whoever hurt them or whom they attacked.
        LivingEntity revenge = owner.getRevengeTarget();
        if (revenge != null && revenge != this && revenge.isAlive() && ticksExisted % 10 == 0 && !isPokieSitting()) {
            setAttackTarget(revenge);
        }
        if (barrierCooldown == 0 && ticksExisted % 5 == 0 && senseDanger(owner)) {
            castBarrier(owner);
        }
    }

    private boolean senseDanger(PlayerEntity owner) {
        if (owner.hurtTime > 0 || owner.getRevengeTimer() > owner.ticksExisted - 40) {
            return true;
        }
        for (MonsterEntity monster : world.getEntitiesWithinAABB(MonsterEntity.class, owner.getBoundingBox().grow(7.0D))) {
            if (monster.getAttackTarget() == owner || monster.getAttackTarget() == this) {
                return true;
            }
        }
        return false;
    }

    /** Converts the 3x3x3 air around the owner (except the ground block and the owner's own cells) to temporary powder snow. */
    private void castBarrier(PlayerEntity owner) {
        barrierCooldown = 400;
        BlockPos center = AstroUtil.blockPos(owner);
        owner.getPersistentData().putLong(AstroUtil.BARRIER_KEY, world.getGameTime() + 170L);
        BlockState snow = ModBlocks.TEMPORARY_POWDER_SNOW.getDefaultState();
        for (int dx = -1; dx <= 1; dx++) {
            for (int dy = -1; dy <= 1; dy++) {
                for (int dz = -1; dz <= 1; dz++) {
                    if (dx == 0 && dz == 0 && dy <= 1) {
                        continue; // ground block, owner's feet and head cells
                    }
                    BlockPos pos = center.add(dx, dy, dz);
                    if (world.isAirBlock(pos) || world.getBlockState(pos).getMaterial().isReplaceable()) {
                        world.setBlockState(pos, snow, 3);
                    }
                }
            }
        }
        playSound(SoundEvents.ENTITY_SNOW_GOLEM_AMBIENT, 1.2F, 0.6F);
        world.playSound(null, owner.getPosX(), owner.getPosY(), owner.getPosZ(), SoundEvents.BLOCK_SNOW_PLACE, SoundCategory.NEUTRAL, 1.5F, 0.7F);
        ((ServerWorld) world).spawnParticle(ParticleTypes.ITEM_SNOWBALL, owner.getPosX(), owner.getPosY() + 1.0D, owner.getPosZ(), 40, 1.0D, 1.0D, 1.0D, 0.05D);
    }

    static final class SitGoal extends Goal {
        private final PokieSnowmanEntity pokie;

        SitGoal(PokieSnowmanEntity pokie) {
            this.pokie = pokie;
            setMutexFlags(EnumSet.of(Goal.Flag.JUMP, Goal.Flag.MOVE));
        }

        @Override
        public boolean shouldExecute() {
            return pokie.isPokieSitting();
        }

        @Override
        public void startExecuting() {
            pokie.getNavigator().clearPath();
        }
    }

    static final class FollowOwnerGoal extends Goal {
        private final PokieSnowmanEntity pokie;
        private final double speed;
        private final float minDistance;
        private final float maxDistance;
        private PlayerEntity owner;
        private int recalc;

        FollowOwnerGoal(PokieSnowmanEntity pokie, double speed, float minDistance, float maxDistance) {
            this.pokie = pokie;
            this.speed = speed;
            this.minDistance = minDistance;
            this.maxDistance = maxDistance;
            setMutexFlags(EnumSet.of(Goal.Flag.MOVE, Goal.Flag.LOOK));
        }

        @Override
        public boolean shouldExecute() {
            PlayerEntity player = pokie.getOwner();
            if (player == null || player.isSpectator() || pokie.isPokieSitting() || pokie.getAttackTarget() != null) {
                return false;
            }
            if (pokie.getDistanceSq(player) < (double) (minDistance * minDistance)) {
                return false;
            }
            owner = player;
            return true;
        }

        @Override
        public boolean shouldContinueExecuting() {
            return owner != null && !pokie.isPokieSitting() && !pokie.getNavigator().noPath()
                && pokie.getDistanceSq(owner) > (double) (minDistance * minDistance) && pokie.getAttackTarget() == null;
        }

        @Override
        public void startExecuting() {
            recalc = 0;
        }

        @Override
        public void tick() {
            pokie.getLookController().setLookPositionWithEntity(owner, 10.0F, (float) pokie.getVerticalFaceSpeed());
            if (--recalc <= 0) {
                recalc = 10;
                if (pokie.getDistanceSq(owner) > 400.0D) {
                    pokie.setLocationAndAngles(owner.getPosX(), owner.getPosY(), owner.getPosZ(), pokie.rotationYaw, 0.0F);
                    pokie.getNavigator().clearPath();
                } else {
                    pokie.getNavigator().tryMoveToEntityLiving(owner, speed);
                }
            }
        }
    }
}
