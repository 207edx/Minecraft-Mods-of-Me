# Changelog
## 2.0.0
- Added Heavy Iron Golem, Heavy Core, Mace (+Density/Breach/Wind Burst), Breeze, Breeze Rod, Wind Charge.
- Leads: villagers/fish, elytra towing, jump-follow, configurable break distance.
- Extra animal spawns, Spear (+Lunge), Powder Snow, Pokie Snowman, Hovering Inferno boss, Heart of the Nether, Nether Trident (+4 enchantments).
- build.gradle: added jar.finalizedBy('reobfJar').
## 1.1.3
- See previous release.
