package com.astro.backport.util;

import java.lang.reflect.Method;
import java.util.UUID;

import com.google.common.collect.ImmutableMultimap;
import com.google.common.collect.Multimap;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.attributes.Attribute;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.entity.ai.attributes.AttributeModifierMap;
import net.minecraft.entity.ai.attributes.GlobalEntityTypeAttributes;
import net.minecraft.entity.ai.attributes.ModifiableAttributeInstance;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.common.ObfuscationReflectionHelper;
import net.minecraftforge.registries.ForgeRegistries;

/**
 * Mapping-independent attribute helpers. Attributes are looked up by registry name and the
 * vanilla attribute map is fetched by its stable SRG name, so this compiles whatever MCP
 * names the snapshot gives the 1.16-only attribute API.
 */
public final class AttrUtil {
    // Same UUIDs vanilla uses, so tooltips show the correct attack values.
    private static final UUID ATTACK_DAMAGE_ID = UUID.fromString("CB3F55D3-645C-4F38-A497-9C13A33DB5CF");
    private static final UUID ATTACK_SPEED_ID = UUID.fromString("FA233E1C-4180-4865-B01B-BCCE9785ACA3");

    private AttrUtil() {}

    public static Attribute attr(String name) {
        return ForgeRegistries.ATTRIBUTES.getValue(new ResourceLocation(name));
    }

    public static void setBase(LivingEntity entity, String name, double value) {
        Attribute attribute = attr(name);
        if (attribute == null) {
            return;
        }
        ModifiableAttributeInstance instance = entity.getAttribute(attribute);
        if (instance != null) {
            instance.setBaseValue(value);
        }
    }

    public static double get(LivingEntity entity, String name) {
        Attribute attribute = attr(name);
        ModifiableAttributeInstance instance = attribute == null ? null : entity.getAttribute(attribute);
        return instance == null ? 0.0D : instance.getValue();
    }

    /** Registers the attribute map of a vanilla type for a custom type (same base attributes). */
    @SuppressWarnings("unchecked")
    public static void copyAttributes(EntityType<?> custom, EntityType<?> vanilla) {
        try {
            Method getter = ObfuscationReflectionHelper.findMethod(GlobalEntityTypeAttributes.class, "func_233835_a_", EntityType.class);
            AttributeModifierMap map = (AttributeModifierMap) getter.invoke(null, vanilla);
            GlobalEntityTypeAttributes.put((EntityType<? extends LivingEntity>) custom, map);
        } catch (Exception exception) {
            throw new RuntimeException("Astro Backport: cannot copy attributes " + vanilla.getRegistryName(), exception);
        }
    }

    public static Multimap<Attribute, AttributeModifier> weapon(double damage, double speedModifier) {
        ImmutableMultimap.Builder<Attribute, AttributeModifier> builder = ImmutableMultimap.builder();
        builder.put(attr("generic.attack_damage"), new AttributeModifier(ATTACK_DAMAGE_ID, "Weapon modifier", damage, AttributeModifier.Operation.ADDITION));
        builder.put(attr("generic.attack_speed"), new AttributeModifier(ATTACK_SPEED_ID, "Weapon modifier", speedModifier, AttributeModifier.Operation.ADDITION));
        return builder.build();
    }
}
