package com.astro.backport.event;

import java.util.List;
import java.util.Random;

import com.astro.backport.AstroBackport;
import com.astro.backport.config.AstroConfig;
import com.astro.backport.util.AstroUtil;

import net.minecraft.block.Blocks;
import net.minecraft.entity.AgeableEntity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.passive.AnimalEntity;
import net.minecraft.entity.passive.SheepEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.server.ServerWorld;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Raises the passive animal population around players (cows, sheep, pigs, chickens). */
@Mod.EventBusSubscriber(modid = AstroBackport.MODID)
public final class SpawnEvents {
    private static final EntityType<?>[] SPECIES = new EntityType<?>[] {EntityType.COW, EntityType.SHEEP, EntityType.PIG, EntityType.CHICKEN};

    private SpawnEvents() {}

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        PlayerEntity player = event.player;
        if (event.phase != TickEvent.Phase.END || player.world.isRemote || !AstroConfig.CFG.extraSpawns.get()) {
            return;
        }
        if (player.ticksExisted % AstroConfig.CFG.spawnInterval.get() != 0) {
            return;
        }
        ServerWorld world = (ServerWorld) player.world;
        Random random = world.rand;
        if (random.nextDouble() > AstroConfig.CFG.spawnChance.get()) {
            return;
        }
        List<AnimalEntity> nearby = world.getEntitiesWithinAABB(AnimalEntity.class, player.getBoundingBox().grow(64.0D, 32.0D, 64.0D));
        if (nearby.size() >= AstroConfig.CFG.spawnCap.get()) {
            return;
        }
        double angle = random.nextDouble() * Math.PI * 2.0D;
        double radius = 24.0D + random.nextDouble() * 20.0D;
        int x = (int) Math.floor(player.getPosX() + Math.cos(angle) * radius);
        int z = (int) Math.floor(player.getPosZ() + Math.sin(angle) * radius);
        BlockPos probe = new BlockPos(x, player.getPosY(), z);
        if (!world.isBlockLoaded(probe) || !AstroUtil.overworldLike(world, probe)) {
            return;
        }
        int y = world.getHeight(net.minecraft.world.gen.Heightmap.Type.MOTION_BLOCKING, x, z);
        BlockPos pos = new BlockPos(x, y, z);
        if (world.getBlockState(pos.down()).getBlock() != Blocks.GRASS_BLOCK) {
            return;
        }
        EntityType<?> species = SPECIES[random.nextInt(SPECIES.length)];
        int count = 2 + random.nextInt(3);
        for (int i = 0; i < count; i++) {
            Object created = species.create(world);
            if (!(created instanceof AnimalEntity)) {
                continue;
            }
            AnimalEntity animal = (AnimalEntity) created;
            animal.setLocationAndAngles(x + 0.5D + random.nextInt(5) - 2, y, z + 0.5D + random.nextInt(5) - 2, random.nextFloat() * 360.0F, 0.0F);
            if (animal instanceof SheepEntity) {
                ((SheepEntity) animal).setFleeceColor(SheepEntity.getRandomSheepColor(random));
            }
            if (random.nextInt(6) == 0) {
                ((AgeableEntity) animal).setGrowingAge(-24000);
            }
            if (animal.canSpawn(world, SpawnReason.NATURAL) && animal.isNotColliding(world)) {
                world.addEntity(animal);
            }
        }
    }
}
