package com.astro.backport;

import com.astro.backport.enchant.AstroEnchantment;
import com.astro.backport.item.MaceItem;
import com.astro.backport.item.NetherTridentItem;
import com.astro.backport.item.SpearItem;

import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentType;
import net.minecraft.inventory.EquipmentSlotType;

public final class ModEnchants {
    private static final EquipmentSlotType[] HANDS = new EquipmentSlotType[] {EquipmentSlotType.MAINHAND};

    public static final EnchantmentType MACE_TYPE = EnchantmentType.create("ASTRO_MACE", item -> item instanceof MaceItem);
    public static final EnchantmentType SPEAR_TYPE = EnchantmentType.create("ASTRO_SPEAR", item -> item instanceof SpearItem);
    public static final EnchantmentType TRIDENT_TYPE = EnchantmentType.create("ASTRO_NETHER_TRIDENT", item -> item instanceof NetherTridentItem);

    // Mace (Density and Breach are mutually exclusive with each other and with Smite/Bane/Sharpness).
    public static final Enchantment DENSITY = new AstroEnchantment(Enchantment.Rarity.UNCOMMON, MACE_TYPE, HANDS, 5, 5, 1).setRegistryName(AstroBackport.MODID, "density");
    public static final Enchantment BREACH = new AstroEnchantment(Enchantment.Rarity.RARE, MACE_TYPE, HANDS, 4, 15, 1).setRegistryName(AstroBackport.MODID, "breach");
    public static final Enchantment WIND_BURST = new AstroEnchantment(Enchantment.Rarity.RARE, MACE_TYPE, HANDS, 3, 15, 0).setRegistryName(AstroBackport.MODID, "wind_burst");

    // Spear
    public static final Enchantment LUNGE = new AstroEnchantment(Enchantment.Rarity.UNCOMMON, SPEAR_TYPE, HANDS, 3, 5, 0).setRegistryName(AstroBackport.MODID, "lunge");

    // Nether Trident
    public static final Enchantment INFERNAL_WARD = new AstroEnchantment(Enchantment.Rarity.RARE, TRIDENT_TYPE, HANDS, 1, 15, 0).setRegistryName(AstroBackport.MODID, "infernal_ward");
    public static final Enchantment LAVA_SIGHT = new AstroEnchantment(Enchantment.Rarity.UNCOMMON, TRIDENT_TYPE, HANDS, 1, 10, 0).setRegistryName(AstroBackport.MODID, "lava_sight");
    public static final Enchantment SCORCH_VELOCITY = new AstroEnchantment(Enchantment.Rarity.RARE, TRIDENT_TYPE, HANDS, 3, 12, 0).setRegistryName(AstroBackport.MODID, "scorch_velocity");
    public static final Enchantment SEARING_EDGE = new AstroEnchantment(Enchantment.Rarity.UNCOMMON, TRIDENT_TYPE, HANDS, 5, 8, 0).setRegistryName(AstroBackport.MODID, "searing_edge");

    private ModEnchants() {}
}
