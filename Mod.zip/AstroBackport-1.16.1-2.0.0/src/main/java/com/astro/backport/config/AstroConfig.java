package com.astro.backport.config;

import net.minecraftforge.common.ForgeConfigSpec;
import org.apache.commons.lang3.tuple.Pair;

public final class AstroConfig {
    public static final ForgeConfigSpec SPEC;
    public static final AstroConfig CFG;

    static {
        Pair<AstroConfig, ForgeConfigSpec> pair = new ForgeConfigSpec.Builder().configure(AstroConfig::new);
        CFG = pair.getLeft();
        SPEC = pair.getRight();
    }

    public final ForgeConfigSpec.DoubleValue heavyGolemChance;
    public final ForgeConfigSpec.BooleanValue extraSpawns;
    public final ForgeConfigSpec.IntValue spawnInterval;
    public final ForgeConfigSpec.DoubleValue spawnChance;
    public final ForgeConfigSpec.IntValue spawnCap;
    public final ForgeConfigSpec.BooleanValue fortressArenas;
    public final ForgeConfigSpec.IntValue maxArenas;
    public final ForgeConfigSpec.IntValue arenaSpacing;
    public final ForgeConfigSpec.DoubleValue leashBreakDistance;

    private AstroConfig(ForgeConfigSpec.Builder b) {
        b.push("golem");
        heavyGolemChance = b.comment("Chance that a newly spawned (village) iron golem becomes a Heavy Iron Golem.")
            .defineInRange("heavyGolemChance", 0.04D, 0.0D, 1.0D);
        b.pop();
        b.push("spawns");
        extraSpawns = b.comment("Extra natural spawns of cows, sheep, pigs and chickens near players.").define("extraSpawns", true);
        spawnInterval = b.comment("Ticks between spawn attempts per player.").defineInRange("spawnInterval", 200, 20, 24000);
        spawnChance = b.comment("Chance per attempt.").defineInRange("spawnChance", 0.6D, 0.0D, 1.0D);
        spawnCap = b.comment("Max passive animals within 64 blocks before extra spawns stop.").defineInRange("spawnCap", 36, 4, 200);
        b.pop();
        b.push("boss");
        fortressArenas = b.comment("Generate a Hovering Inferno arena when a player explores a Nether fortress.").define("fortressArenas", true);
        maxArenas = b.comment("Max arenas per Nether world.").defineInRange("maxArenas", 6, 0, 100);
        arenaSpacing = b.comment("Minimum blocks between arenas.").defineInRange("arenaSpacing", 400, 64, 5000);
        b.pop();
        b.push("leash");
        leashBreakDistance = b.comment("Distance at which custom leashes snap.").defineInRange("leashBreakDistance", 16.0D, 6.0D, 64.0D);
        b.pop();
    }
}
