package com.astro.backport.event;

import java.util.Iterator;
import java.util.Map;
import java.util.WeakHashMap;

import com.astro.backport.AstroBackport;

import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.potion.EffectInstance;
import net.minecraft.potion.Effects;
import net.minecraft.util.DamageSource;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Powder snow freezing: time inside builds up; when full the entity is slowed and takes damage. */
@Mod.EventBusSubscriber(modid = AstroBackport.MODID)
public final class FreezeManager {
    public static final DamageSource FREEZE = new DamageSource("astro_freeze").setDamageBypassesArmor();
    private static final Map<Entity, int[]> STATE = new WeakHashMap<Entity, int[]>();

    private FreezeManager() {}

    /** Called by the block every tick an entity is inside. Server only. */
    public static void touch(Entity entity) {
        if (!(entity instanceof LivingEntity)) {
            return;
        }
        int[] state = STATE.get(entity);
        if (state == null) {
            state = new int[2];
            STATE.put(entity, state);
        }
        state[1] = 1;
    }

    public static int frozenTicks(Entity entity) {
        int[] state = STATE.get(entity);
        return state == null ? 0 : state[0];
    }

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || STATE.isEmpty()) {
            return;
        }
        Iterator<Map.Entry<Entity, int[]>> iterator = STATE.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<Entity, int[]> entry = iterator.next();
            LivingEntity entity = (LivingEntity) entry.getKey();
            int[] state = entry.getValue();
            if (entity == null || !entity.isAlive()) {
                iterator.remove();
                continue;
            }
            state[0] = state[1] == 1 ? Math.min(state[0] + 2, 200) : Math.max(state[0] - 2, 0);
            state[1] = 0;
            if (state[0] >= 140) {
                entity.addPotionEffect(new EffectInstance(Effects.SLOWNESS, 25, 0, false, false));
                if (entity.ticksExisted % 40 == 0) {
                    entity.attackEntityFrom(FREEZE, 1.0F);
                }
            }
            if (state[0] == 0) {
                iterator.remove();
            }
        }
    }
}
