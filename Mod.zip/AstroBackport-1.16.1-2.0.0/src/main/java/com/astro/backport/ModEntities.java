package com.astro.backport;

import com.astro.backport.entity.BreezeEntity;
import com.astro.backport.entity.HeavyIronGolemEntity;
import com.astro.backport.entity.HoveringInfernoEntity;
import com.astro.backport.entity.PokieSnowmanEntity;
import com.astro.backport.entity.WindChargeEntity;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityClassification;
import net.minecraft.entity.EntityType;

public final class ModEntities {
    private static <T extends Entity> EntityType<T> reg(EntityType<T> type, String name) {
        type.setRegistryName(AstroBackport.MODID, name);
        return type;
    }

    public static final EntityType<WindChargeEntity> WIND_CHARGE = reg(EntityType.Builder.<WindChargeEntity>create(WindChargeEntity::new, EntityClassification.MISC)
        .size(0.3125F, 0.3125F).setTrackingRange(4).setUpdateInterval(10).setShouldReceiveVelocityUpdates(true).build("wind_charge"), "wind_charge");
    public static final EntityType<BreezeEntity> BREEZE = reg(EntityType.Builder.<BreezeEntity>create(BreezeEntity::new, EntityClassification.MONSTER)
        .size(0.6F, 1.77F).setTrackingRange(8).build("breeze"), "breeze");
    public static final EntityType<HeavyIronGolemEntity> HEAVY_IRON_GOLEM = reg(EntityType.Builder.<HeavyIronGolemEntity>create(HeavyIronGolemEntity::new, EntityClassification.MISC)
        .size(2.45F, 4.7F).setTrackingRange(10).build("heavy_iron_golem"), "heavy_iron_golem");
    public static final EntityType<HoveringInfernoEntity> HOVERING_INFERNO = reg(EntityType.Builder.<HoveringInfernoEntity>create(HoveringInfernoEntity::new, EntityClassification.MONSTER)
        .size(2.4F, 3.0F).immuneToFire().setTrackingRange(12).build("hovering_inferno"), "hovering_inferno");
    public static final EntityType<PokieSnowmanEntity> POKIE_SNOWMAN = reg(EntityType.Builder.<PokieSnowmanEntity>create(PokieSnowmanEntity::new, EntityClassification.CREATURE)
        .size(0.7F, 1.9F).setTrackingRange(8).build("pokie_snowman"), "pokie_snowman");

    private ModEntities() {}

    public static EntityType<?>[] all() {
        return new EntityType<?>[] {WIND_CHARGE, BREEZE, HEAVY_IRON_GOLEM, HOVERING_INFERNO, POKIE_SNOWMAN};
    }
}
